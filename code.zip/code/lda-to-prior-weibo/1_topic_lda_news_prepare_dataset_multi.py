# -*- coding: utf-8 -*-

import os
import sys
import pickle
import random
import numpy as np
import argparse
from tqdm import tqdm
from collections import defaultdict
#import paddlehub as hub


def unsup_train():
    random.seed(42)

    with open('ano_douban_data_unsup_train.tsv', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    documents = [[int(lines[0].strip().split('\t')[0]), None]]
    last_emotion = [0, 0, 0, 0, 0]
    for line in tqdm(lines):
        items = line.strip().split('\t')
        if int(items[0]) != documents[-1][0]:
            last_emotion = [0, 0, 0, 0, 0]
        last_emotion[int(items[2])] = 1
        documents.append([int(items[0]), last_emotion])
    documents = documents[1:]
    
    with open('/users4/xlu/emotion-inference/baidu_topic_dataset_weibo_unify_strict/topic_lda_news_multi_unsup_train.pkl', 'rb') as f:
        topic_dist_list = pickle.load(f)
    
    assert (len(documents) == len(topic_dist_list))
    print('documents(before): %d' % len(documents))
    
    all_documents = []
    for i in tqdm(range(len(documents))):
        if len(topic_dist_list[i]) > 0:
            dialog_id = documents[i][0]
            emotion = documents[i][1]
            topic = [0 for _ in range(2000)]
            for item in topic_dist_list[i]:
                topic[int(item['topic id'])] = float(item['distribution'])
            all_documents.append([dialog_id, topic, emotion])
        else:
            dialog_id = documents[i][0]
            emotion = documents[i][1]
            topic = [1 / 2000 for _ in range(2000)]
            all_documents.append([dialog_id, topic, emotion])
            
    print('documents(after): %d' % len(all_documents))
    
    all_dialog_id = list(set([x[0] for x in all_documents]))
    random.shuffle(all_dialog_id)
    train_dialog_id = set(all_dialog_id[0:int(len(all_dialog_id)*0.9)])
    dev_dialog_id = set(all_dialog_id[int(len(all_dialog_id)*0.9):int(len(all_dialog_id)*0.95)])
    test_dialog_id = set(all_dialog_id[int(len(all_dialog_id)*0.95):])
    
    train_documents = []
    for document in all_documents:
        if document[0] in train_dialog_id:
            train_documents.append(document[1:])
    with open('topic_lda_news_multi_unsup_train_t2e_train.pkl', 'wb') as f:
        pickle.dump(train_documents, f)
    
    dev_documents = []
    for document in all_documents:
        if document[0] in dev_dialog_id:
            dev_documents.append(document[1:])
    with open('topic_lda_news_multi_unsup_train_t2e_dev.pkl', 'wb') as f:
        pickle.dump(dev_documents, f)
    
    test_documents = []
    for document in all_documents:
        if document[0] in test_dialog_id:
            test_documents.append(document[1:])
    with open('topic_lda_news_multi_unsup_train_t2e_test.pkl', 'wb') as f:
        pickle.dump(test_documents, f)


def main():
    unsup_train()
    

if __name__ == '__main__':
    main()
