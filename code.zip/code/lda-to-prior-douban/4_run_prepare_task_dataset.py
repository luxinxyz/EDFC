# -*- coding: utf-8 -*-

import os
import random
import pickle
import argparse
from tqdm import tqdm
from pytorch_pretrained_bert.tokenization import BertTokenizer


MAX_LEN = 256


class InputFeatures(object):
    def __init__(self, input_ids, input_mask, label_dist, label_id):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.label_dist = label_dist
        self.label_id = label_id


def texts_to_ids_and_mask(texts):
    tokenizer = BertTokenizer('vocab.txt', never_split=("[UNK]", "[SEP]", "[PAD]", "[CLS]", "[MASK]"))

    dialog_context_texts = texts
    dialog_context_length = len(dialog_context_texts)
    dialog_context_special_tokens_count = dialog_context_length + 1
    dialog_context_normal_tokens_max_count = MAX_LEN - dialog_context_special_tokens_count
    dialog_context_texts_tokens = [tokenizer.tokenize(text) for text in dialog_context_texts]
    
    turn_index = 0
    while sum([len(x) for x in dialog_context_texts_tokens]) > dialog_context_normal_tokens_max_count:
        if len(dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)]) <= 1:
            turn_index += 1
        else:
            dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)] = dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)][0:-1]
            turn_index += 1
    assert (sum([len(x) for x in dialog_context_texts_tokens]) <= dialog_context_normal_tokens_max_count)
    assert (len(dialog_context_texts) == len(dialog_context_texts_tokens))
    
    dialog_context_tokens = ["[CLS]"]
    for text_tokens in dialog_context_texts_tokens:
        dialog_context_tokens = dialog_context_tokens + text_tokens + ["[SEP]"]

    combine_dialog_context_length = len(dialog_context_tokens)
    combine_dialog_context_token_ids = tokenizer.convert_tokens_to_ids(dialog_context_tokens) + [0 for x in range(MAX_LEN - combine_dialog_context_length)]
    combine_dialog_context_mask = [1 for x in range(combine_dialog_context_length)] + [0 for x in range(MAX_LEN - combine_dialog_context_length)]

    assert (len(combine_dialog_context_token_ids) == MAX_LEN)
    assert (len(combine_dialog_context_mask) == MAX_LEN)
    
    return [combine_dialog_context_token_ids, combine_dialog_context_mask]


def process_text(raw_data):
    with open(raw_data, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    pre_documents = []
    last_document = []
    for line in tqdm(lines):
        items = line.strip().split('\t')
        if (len(last_document) > 0) and (int(items[0]) != int(last_document[-1][0])):
            pre_documents.append(last_document)
            last_document = []
        last_document.append(items)
    if len(last_document) > 0:
        pre_documents.append(last_document)
    
    documents = []
    for document in tqdm(pre_documents):
        assert (len(document) > 1)
        for i in range(1, len(document)):
            texts = [x[1].strip() for x in document[0:i]]
            emotion = document[i][2]
            documents.append(texts_to_ids_and_mask(texts) + [emotion])
    
    return documents


def process_dist(raw_data):
    with open(raw_data, 'r', encoding='utf-8') as f:
        dists = [[float(x) for x in line.strip().split('\t')] for line in f.readlines()]
    
    return dists


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--text_data", default=None, type=str, required=True)
    parser.add_argument("--dist_data", default=None, type=str, required=True)
    parser.add_argument("--output", default=None, type=str, required=True)
    args = parser.parse_args()

    documents = process_text(args.text_data)
    print(len(documents))
    
    dists = process_dist(args.dist_data)
    print(len(dists))
    
    assert (len(documents) == len(dists))
    
    all_features = []
    for i in range(len(documents)):
        all_features.append(InputFeatures(input_ids=documents[i][0], 
                                          input_mask=documents[i][1], 
                                          label_dist=dists[i], 
                                          label_id=documents[i][2]))
    
    with open(args.output, 'wb') as f:
        pickle.dump(all_features, f)
    
    print(len(all_features))


if __name__ == '__main__':
    main()
