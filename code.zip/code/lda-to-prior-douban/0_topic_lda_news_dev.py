# -*- coding: utf-8 -*-

import os
import sys
import pickle
import argparse
from tqdm import tqdm
import paddlehub as hub


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", default=None, type=int, required=True)
    parser.add_argument("-e", default=None, type=int, required=True)
    args = parser.parse_args()

    lda_news = hub.Module(name="lda_news")
    
    with open('ano_douban_data_dev.tsv', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    documents = [[int(lines[0].strip().split('\t')[0]), '']]
    last_document = ''
    for line in tqdm(lines):
        items = line.strip().split('\t')
        if int(items[0]) != documents[-1][0]:
            last_document = ''
            documents.pop()
        last_document = last_document + ' ' + items[1] + ' ' + '。'
        last_document = last_document.strip()
        documents.append([int(items[0]), last_document])
    documents.pop()
    documents = documents[1:]
    
    # for i in range(20):
    #     print(documents[i])
    # print('')
    # for i in range(len(documents)-20, len(documents)):
    #     print(documents[i])
    # return
    
    documents = [x[1] for x in documents if x[0] >= args.s and x[0] <= args.e]
    
    topic_dist_list = []
    for document in tqdm(documents):
        topic_dist = lda_news.infer_doc_topic_distribution(document)
        topic_dist_list.append(topic_dist)
    
    with open('topic_lda_news_multi_dev_%d_%d.pkl' % (args.s, args.e), 'wb') as f:
        pickle.dump(topic_dist_list, f)
    

if __name__ == '__main__':
    main()
