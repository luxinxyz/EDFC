import os
import sys
import csv
from argparse import ArgumentParser
from pathlib import Path
import torch
import logging
import json
import random
import numpy as np
from collections import namedtuple
from tempfile import TemporaryDirectory

from torch.utils.data import (DataLoader, RandomSampler, SequentialSampler, TensorDataset)
from torch.utils.data import DataLoader, Dataset, RandomSampler
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm
import shelve
from sklearn import metrics
import pickle
import math

from pytorch_pretrained_bert.modeling import BertConfig, Topic2EmotionModelSplitSoftmaxBefore
from pytorch_pretrained_bert.tokenization import BertTokenizer
from pytorch_pretrained_bert.optimization import BertAdam, warmup_linear


log_format = '%(asctime)-10s: %(message)s'
logging.basicConfig(level=logging.INFO, format=log_format)
logger = logging.getLogger(__name__)


class Topic2EmotionDataset(Dataset):
    def __init__(self, filename, num_topics=2000, num_emotions=5):
        with open(filename, 'rb') as f:
            self.data = pickle.load(f)
        self.num_topics = num_topics
        self.num_emotions = num_emotions

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        return torch.FloatTensor(self.data[index][0]), torch.LongTensor(self.data[index][1])


def main():
    parser = ArgumentParser()
    
    parser.add_argument("--dataset", default=None, type=str, required=True)
    parser.add_argument("--model", default=None, type=str, required=True)
    parser.add_argument("--num_topics", default=None, type=int, required=True)
    parser.add_argument("--num_emotions", default=None, type=int, required=True)
    
    parser.add_argument('--output_dir', type=Path, required=True)
    
    parser.add_argument("--eval_batch_size", default=8, type=int, help="Total batch size for eval.")

    parser.add_argument('--fp16', action='store_true', help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    parser.add_argument('--fp16_opt_level', type=str, default='O1', help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3'].")
    
    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--local_rank", type=int, default=-1, help="local_rank for distributed training on gpus")
    
    parser.add_argument('--seed', type=int, default=42, help="random seed for initialization")
    
    args = parser.parse_args()

    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)


    if args.output_dir.is_dir() and list(args.output_dir.iterdir()):
        logging.warning(f"Output directory ({args.output_dir}) already exists and is not empty!")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    
    
    eval_data = Topic2EmotionDataset(args.dataset, num_topics=args.num_topics, num_emotions=args.num_emotions)

    
    # Prepare model
    model = Topic2EmotionModelSplitSoftmaxBefore(num_topics=args.num_topics, num_emotions=args.num_emotions)
    model.load_state_dict(torch.load(args.model))
    model.to(device)
    
    
    # Prepare fp16
    if args.fp16:
        try:
            from apex import amp
        except ImportError:
            raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
        model = amp.initialize(model, opt_level=args.fp16_opt_level)
    

    # eval dataloader
    logger.info("***** evaluation *****")
    logger.info("  Num examples = %d", len(eval_data))
    logger.info("  Batch size = %d", args.eval_batch_size)
    eval_sampler = SequentialSampler(eval_data)
    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=args.eval_batch_size)

    
    # eval
    with open(os.path.join(args.output_dir, 'eval_result.tsv'), 'w', encoding='utf-8') as f:
        model.eval()
        for dialog2topic, _ in tqdm(eval_dataloader, desc="Evaluating"):
            dialog2topic = dialog2topic.to(device)

            with torch.no_grad():
                probs = model(dialog2topic)

            probs = probs.tolist()
            for prob in probs:
                f.write('%s\n' % '\t'.join([str(x) for x in prob]))


if __name__ == '__main__':
    # import ipdb
    # ipdb.set_trace()
    main()
