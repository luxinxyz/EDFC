import os
import sys
import csv
from argparse import ArgumentParser
from pathlib import Path
import torch
import logging
import json
import random
import numpy as np
from collections import namedtuple
from tempfile import TemporaryDirectory

from torch.utils.data import (DataLoader, RandomSampler, SequentialSampler, TensorDataset)
from torch.utils.data import DataLoader, Dataset, RandomSampler
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm
import shelve
from sklearn import metrics
import pickle
import math

from pytorch_pretrained_bert.modeling import BertConfig, Topic2EmotionModelSplitSoftmaxBefore
from pytorch_pretrained_bert.tokenization import BertTokenizer
from pytorch_pretrained_bert.optimization import BertAdam, warmup_linear


log_format = '%(asctime)-10s: %(message)s'
logging.basicConfig(level=logging.INFO, format=log_format)
logger = logging.getLogger(__name__)


class Topic2EmotionDataset(Dataset):
    def __init__(self, filename, num_topics=2000, num_emotions=5):
        with open(filename, 'rb') as f:
            self.data = pickle.load(f)
        self.num_topics = num_topics
        self.num_emotions = num_emotions

    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        return torch.FloatTensor(self.data[index][0]), torch.LongTensor(self.data[index][1])


def main():
    parser = ArgumentParser()
    
    parser.add_argument("--dataset_train", default=None, type=str, required=True)
    parser.add_argument("--dataset_dev", default=None, type=str, required=True)
    parser.add_argument("--num_topics", default=None, type=int, required=True)
    parser.add_argument("--num_emotions", default=None, type=int, required=True)

    parser.add_argument('--output_dir', type=Path, required=True)
    
    parser.add_argument("--epochs", type=int, default=3, help="Number of epochs to train for")
    parser.add_argument("--train_batch_size", default=32, type=int, help="Total batch size for training.")
    parser.add_argument("--eval_batch_size", default=8, type=int, help="Total batch size for eval.")
    parser.add_argument("--learning_rate", default=2e-5, type=float, help="The initial learning rate for Adam.")
    parser.add_argument("--warmup_steps_or_proportion", default=0.1, type=float, help="Proportion of training to perform linear learning rate warmup for.")
    parser.add_argument("--warmup_type", default='warmup_linear', type=str, help="Warmup Type.")
    parser.add_argument("--weight_decay", default=0.01, type=float, help="Weight decay.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")

    parser.add_argument('--gradient_accumulation_steps', type=int, default=1, help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument('--fp16', action='store_true', help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    parser.add_argument('--fp16_opt_level', type=str, default='O1', help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3'].")
    
    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--local_rank", type=int, default=-1, help="local_rank for distributed training on gpus")
    
    parser.add_argument('--seed', type=int, default=42, help="random seed for initialization")
    
    args = parser.parse_args()

    
    if args.local_rank == -1:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        n_gpu = torch.cuda.device_count()
    else:
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        n_gpu = 1
        # Initializes the distributed backend which will take care of sychronizing nodes/GPUs
        torch.distributed.init_process_group(backend='nccl')
    logging.info("device: {} n_gpu: {}, distributed training: {}, 16-bits training: {}".format(
        device, n_gpu, bool(args.local_rank != -1), args.fp16))


    if args.gradient_accumulation_steps < 1:
        raise ValueError("Invalid gradient_accumulation_steps parameter: {}, should be >= 1".format(
                            args.gradient_accumulation_steps))


    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if n_gpu > 0:
        torch.cuda.manual_seed_all(args.seed)


    if args.output_dir.is_dir() and list(args.output_dir.iterdir()):
        logging.warning(f"Output directory ({args.output_dir}) already exists and is not empty!")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    
    
    train_data = Topic2EmotionDataset(args.dataset_train, num_topics=args.num_topics, num_emotions=args.num_emotions)
    eval_data = Topic2EmotionDataset(args.dataset_dev, num_topics=args.num_topics, num_emotions=args.num_emotions)
    
    
    args.train_batch_size = args.train_batch_size // args.gradient_accumulation_steps
    
    total_train_examples = args.epochs * len(train_data)
    num_train_optimization_steps = int(total_train_examples / args.train_batch_size / args.gradient_accumulation_steps)
    if args.local_rank != -1:
        num_train_optimization_steps = num_train_optimization_steps // torch.distributed.get_world_size()


    # Prepare model
    model = Topic2EmotionModelSplitSoftmaxBefore(num_topics=args.num_topics, num_emotions=args.num_emotions)
    model.to(device)
    
    
    # Prepare optimizer
    param_optimizer = list(model.named_parameters())
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)], 'weight_decay': args.weight_decay},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    
    # Prepare warmup
    if args.warmup_steps_or_proportion > 1.0:
        args.warmup_proportion = args.warmup_steps_or_proportion / num_train_optimization_steps
    else:
        args.warmup_proportion = args.warmup_steps_or_proportion

    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=args.learning_rate,
                         warmup=args.warmup_proportion,
                         schedule=args.warmup_type,
                         t_total=num_train_optimization_steps if args.warmup_proportion != -1 else -1)

    # Prepare fp16
    if args.fp16:
        try:
            from apex import amp
        except ImportError:
            raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
        model, optimizer = amp.initialize(model, optimizer, opt_level=args.fp16_opt_level)
    
    # Prepare Parallel
    if n_gpu > 1:
        model = torch.nn.DataParallel(model)

    # eval dataloader
    logger.info("***** evaluation *****")
    logger.info("  Num examples = %d", len(eval_data))
    logger.info("  Batch size = %d", args.eval_batch_size)
    eval_sampler = SequentialSampler(eval_data)
    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=args.eval_batch_size)

    # train dataloader
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_data))
    logger.info("  Batch size = %d", args.train_batch_size * args.gradient_accumulation_steps)
    logger.info("  Num steps = %d", num_train_optimization_steps)
    train_sampler = RandomSampler(train_data)
    train_dataloader = DataLoader(train_data, sampler=train_sampler, batch_size=args.train_batch_size)
    
    
    # main loop
    for epoch in range(args.epochs):
        # train
        model.train()
    
        tr_loss = 0
        nb_tr_steps = 0
        nb_tr_examples = 0
        
        with tqdm(total=int(len(train_dataloader) / args.gradient_accumulation_steps), desc=f"Epoch {epoch}") as pbar:
            for step, batch in enumerate(train_dataloader):
                batch = tuple(t.to(device) for t in batch)
                dialog2topic, emotions = batch
                
                loss = model(dialog2topic, emotions)
                
                if n_gpu > 1:
                    loss = loss.mean()
                if args.gradient_accumulation_steps > 1:
                    loss = loss / args.gradient_accumulation_steps
                
                if args.fp16:
                    with amp.scale_loss(loss, optimizer) as scaled_loss:
                        scaled_loss.backward()
                else:
                    loss.backward()

                nb_tr_steps += 1
                nb_tr_examples += dialog2topic.size(0)
                tr_loss += loss.item()
                mean_loss = tr_loss * args.gradient_accumulation_steps / nb_tr_steps

                if (step + 1) % args.gradient_accumulation_steps == 0:
                    pbar.update(1)
                    pbar.set_postfix_str('Loss=%.5f' % (mean_loss))
                    
                    if args.fp16:
                        torch.nn.utils.clip_grad_norm_(amp.master_params(optimizer), args.max_grad_norm)
                    else:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

                    optimizer.step()
                    model.zero_grad()


        # eval
        model.eval()
        
        eval_loss = 0
        nb_eval_steps = 0

        for dialog2topic, emotions in tqdm(eval_dataloader, desc="Evaluating"):
            dialog2topic = dialog2topic.to(device)
            emotions = emotions.to(device)

            with torch.no_grad():
                tmp_eval_loss = model(dialog2topic, emotions)

            eval_loss += tmp_eval_loss.mean().item()
            nb_eval_steps += 1

        eval_loss = eval_loss / nb_eval_steps
        
        result = {'eval_loss': eval_loss}

        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(result[key]))
        
        
        logging.info("** ** * Epoch: %d, Percent: %d%%, Saving fine-tuned model ** ** * " % (epoch, 100))
        model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
        output_model_file = args.output_dir / ("model_epoch-%d_percent-%.2f_loss-%.5f_loss-%.5f.bin" % (epoch, 1.0, mean_loss, eval_loss))
        torch.save(model_to_save.state_dict(), str(output_model_file))
        


if __name__ == '__main__':
    # import ipdb
    # ipdb.set_trace()
    main()
