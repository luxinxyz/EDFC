import os
import sys
import csv
from argparse import ArgumentParser
from pathlib import Path
import torch
import logging
import json
import random
import numpy as np
from collections import namedtuple
from tempfile import TemporaryDirectory

from torch.utils.data import (DataLoader, RandomSampler, SequentialSampler, TensorDataset)
from torch.utils.data import DataLoader, Dataset, RandomSampler
from torch.utils.data.distributed import DistributedSampler
from tqdm import tqdm
import shelve
from sklearn import metrics
import pickle
import math
import copy

from pytorch_pretrained_bert.modeling_prior_cls import BertConfig, BertForSequenceClassification
from pytorch_pretrained_bert.tokenization import BertTokenizer
from pytorch_pretrained_bert.optimization import BertAdam, warmup_linear


log_format = '%(asctime)-10s: %(message)s'
logging.basicConfig(level=logging.INFO, format=log_format)
logger = logging.getLogger(__name__)


class InputFeatures(object):
    def __init__(self, input_ids, input_mask, label_dist, label_id):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.label_dist = label_dist
        self.label_id = label_id


def main():
    parser = ArgumentParser()
    
    parser.add_argument("--data_train", default=None, type=str, required=True)
    parser.add_argument("--data_valid", default=None, type=str, required=True)
    parser.add_argument("--data_test", default=None, type=str, required=True)
    
    parser.add_argument("--num_labels", default=None, type=int, required=True)
    
    parser.add_argument("--bert_model", default=None, type=str, required=True)
    parser.add_argument("--vocab_file", default=None, type=str, required=True)
    parser.add_argument('--output_dir', type=Path, required=True)
    parser.add_argument('--output_dir_test', type=Path, required=True)

    parser.add_argument("--epochs", type=int, default=3, help="Number of epochs to train for")
    parser.add_argument("--train_batch_size", default=32, type=int, help="Total batch size for training.")
    parser.add_argument("--eval_batch_size", default=8, type=int, help="Total batch size for eval.")
    parser.add_argument("--learning_rate", default=2e-5, type=float, help="The initial learning rate for Adam.")
    parser.add_argument("--warmup_steps_or_proportion", default=0.1, type=float, help="Proportion of training to perform linear learning rate warmup for.")
    parser.add_argument("--warmup_type", default='warmup_linear', type=str, help="Warmup Type.")
    parser.add_argument("--weight_decay", default=0.01, type=float, help="Weight decay.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")
    parser.add_argument("--max_seq_length", default=256, type=int, help="")

    parser.add_argument('--gradient_accumulation_steps', type=int, default=1, help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument('--fp16', action='store_true', help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    parser.add_argument('--fp16_opt_level', type=str, default='O1', help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3'].")
    
    parser.add_argument("--do_lower_case", action="store_true")
    parser.add_argument("--local_rank", type=int, default=-1, help="local_rank for distributed training on gpus")
    
    parser.add_argument('--seed', type=int, default=42, help="random seed for initialization")
    
    args = parser.parse_args()

    
    if args.local_rank == -1:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        n_gpu = torch.cuda.device_count()
    else:
        torch.cuda.set_device(args.local_rank)
        device = torch.device("cuda", args.local_rank)
        n_gpu = 1
        # Initializes the distributed backend which will take care of sychronizing nodes/GPUs
        torch.distributed.init_process_group(backend='nccl')
    logging.info("device: {} n_gpu: {}, distributed training: {}, 16-bits training: {}".format(
        device, n_gpu, bool(args.local_rank != -1), args.fp16))


    if args.gradient_accumulation_steps < 1:
        raise ValueError("Invalid gradient_accumulation_steps parameter: {}, should be >= 1".format(
                            args.gradient_accumulation_steps))


    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if n_gpu > 0:
        torch.cuda.manual_seed_all(args.seed)

    
    tokenizer = BertTokenizer(vocab_file=args.vocab_file, do_lower_case=args.do_lower_case)


    if args.output_dir.is_dir() and list(args.output_dir.iterdir()):
        logging.warning(f"Output directory ({args.output_dir}) already exists and is not empty!")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    
    if args.output_dir_test.is_dir() and list(args.output_dir_test.iterdir()):
        logging.warning(f"Output directory ({args.output_dir_test}) already exists and is not empty!")
    args.output_dir_test.mkdir(parents=True, exist_ok=True)
    
    
    with open(args.data_train, 'rb') as f:
        train_features = pickle.load(f)
    
    with open(args.data_valid, 'rb') as f:
        eval_features = pickle.load(f)
    
    with open(args.data_test, 'rb') as f:
        test_features = pickle.load(f)
    
    
    args.train_batch_size = args.train_batch_size // args.gradient_accumulation_steps
    
    total_train_examples = args.epochs * len(train_features)
    num_train_optimization_steps = int(total_train_examples / args.train_batch_size / args.gradient_accumulation_steps)
    if args.local_rank != -1:
        num_train_optimization_steps = num_train_optimization_steps // torch.distributed.get_world_size()


    # Prepare model
    model = BertForSequenceClassification.from_pretrained(args.bert_model, num_labels=args.num_labels)
    model.to(device)
    
    
    # Prepare optimizer
    param_optimizer = list(model.named_parameters())
    no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
    optimizer_grouped_parameters = [
        {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
         'weight_decay': args.weight_decay},
        {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    ]
    
    # Prepare warmup
    if args.warmup_steps_or_proportion > 1.0:
        args.warmup_proportion = args.warmup_steps_or_proportion / num_train_optimization_steps
    else:
        args.warmup_proportion = args.warmup_steps_or_proportion

    optimizer = BertAdam(optimizer_grouped_parameters,
                         lr=args.learning_rate,
                         warmup=args.warmup_proportion,
                         schedule=args.warmup_type,
                         t_total=num_train_optimization_steps if args.warmup_proportion != -1 else -1)

    # Prepare fp16
    if args.fp16:
        try:
            from apex import amp
        except ImportError:
            raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
        model, optimizer = amp.initialize(model, optimizer, opt_level=args.fp16_opt_level)
    
    # Prepare Parallel
    if n_gpu > 1:
        model = torch.nn.DataParallel(model)

    
    # eval dataloader
    logger.info("***** evaluation *****")
    logger.info("  Num examples = %d", len(eval_features))
    logger.info("  Batch size = %d", args.eval_batch_size)
    all_input_ids = torch.tensor([f.input_ids for f in eval_features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in eval_features], dtype=torch.long)
    all_label_dist = torch.tensor([f.label_dist for f in eval_features], dtype=torch.float)
    all_label_id = torch.tensor([int(f.label_id) for f in eval_features], dtype=torch.long)
    eval_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
    eval_sampler = SequentialSampler(eval_data)
    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=args.eval_batch_size)
    
    # test dataloader
    logger.info("***** test *****")
    logger.info("  Num examples = %d", len(test_features))
    logger.info("  Batch size = %d", args.eval_batch_size)
    all_input_ids = torch.tensor([f.input_ids for f in test_features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in test_features], dtype=torch.long)
    all_label_dist = torch.tensor([f.label_dist for f in test_features], dtype=torch.float)
    all_label_id = torch.tensor([int(f.label_id) for f in test_features], dtype=torch.long)
    test_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
    test_sampler = SequentialSampler(test_data)
    test_dataloader = DataLoader(test_data, sampler=test_sampler, batch_size=args.eval_batch_size)
    
    # train dataloader
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_features))
    logger.info("  Batch size = %d", args.train_batch_size * args.gradient_accumulation_steps)
    logger.info("  Num steps = %d", num_train_optimization_steps)
    all_input_ids = torch.tensor([f.input_ids for f in train_features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in train_features], dtype=torch.long)
    all_label_dist = torch.tensor([f.label_dist for f in train_features], dtype=torch.float)
    all_label_id = torch.tensor([int(f.label_id) for f in train_features], dtype=torch.long)
    train_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
    train_sampler = RandomSampler(train_data)
    train_dataloader = DataLoader(train_data, sampler=train_sampler, batch_size=args.train_batch_size)
    
    
    # main loop
    for epoch in range(args.epochs):
        # train
        model.train()
    
        tr_loss = 0
        tr_accuracy = 0
        nb_tr_steps = 0
        nb_tr_examples = 0
        nb_tr_examples_wo_n = 0
        
        tr_loss_ce = 0
        tr_loss_ce_wo_n = 0
        
        logits_list = []
        label_ids_list = []
        
        with tqdm(total=int(len(train_dataloader) / args.gradient_accumulation_steps), desc=f"Epoch {epoch}") as pbar:
            for step, batch in enumerate(train_dataloader):
                batch = tuple(t.to(device) for t in batch)
                input_ids, input_mask, label_dists, label_ids = batch
                
                loss, logits = model(input_ids, input_mask, label_dists, label_ids)
                label_dists_pred = torch.nn.Softmax(dim=-1)(logits)
                label_dists_pred_wo_n = (label_dists_pred / label_dists_pred[:, 1:].sum(dim=-1, keepdim=True))[:, 1:]
                
                wo_n_select = (copy.deepcopy(label_ids) != 0)
                
                std_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred), label_ids).item()
                wo_n_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred_wo_n[wo_n_select]), label_ids[wo_n_select] - 1).item()
                
                if n_gpu > 1:
                    loss = loss.mean()
                if args.gradient_accumulation_steps > 1:
                    loss = loss / args.gradient_accumulation_steps
                
                if args.fp16:
                    with amp.scale_loss(loss, optimizer) as scaled_loss:
                        scaled_loss.backward()
                else:
                    loss.backward()
                
                logits = logits.detach().cpu().numpy()
                label_ids = label_ids.to('cpu').numpy()
                
                logits_list = [int(x) for x in np.argmax(logits, axis=1)]
                label_ids_list = [int(x) for x in label_ids]
                
                tmp_accuracy = metrics.accuracy_score(label_ids_list, logits_list)
                tr_accuracy += tmp_accuracy * input_ids.size(0)

                tr_loss += loss.item()
                nb_tr_steps += 1
                nb_tr_examples += input_ids.size(0)
                nb_tr_examples_wo_n += int(wo_n_select.sum().item())
                
                tr_loss_ce += std_ce
                tr_loss_ce_wo_n += wo_n_ce
                
                mean_loss = tr_loss * args.gradient_accumulation_steps / nb_tr_steps
                
                mean_loss_ce = tr_loss_ce * args.gradient_accumulation_steps / nb_tr_examples
                mean_loss_ce_wo_n = tr_loss_ce_wo_n * args.gradient_accumulation_steps / nb_tr_examples_wo_n

                if (step + 1) % args.gradient_accumulation_steps == 0:
                    pbar.update(1)
                    pbar.set_postfix_str('Loss=%.5f, CE=%.5f, CE-E=%.5f' % (mean_loss, mean_loss_ce, mean_loss_ce_wo_n))
                    
                    if args.fp16:
                        torch.nn.utils.clip_grad_norm_(amp.master_params(optimizer), args.max_grad_norm)
                    else:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)

                    optimizer.step()
                    model.zero_grad()


        # eval
        model.eval()
        
        eval_loss = 0
        nb_eval_steps = 0
        nb_eval_examples = 0
        nb_eval_examples_wo_n = 0
        
        eval_loss_ce = 0
        eval_loss_ce_wo_n = 0
        
        logits_list = []
        logits_raw_list = []
        label_ids_list = []

        for input_ids, input_mask, label_dists, label_ids in tqdm(eval_dataloader, desc="Evaluating"):
            input_ids = input_ids.to(device)
            input_mask = input_mask.to(device)
            label_dists = label_dists.to(device)
            label_ids = label_ids.to(device)

            with torch.no_grad():
                loss, logits = model(input_ids, input_mask, label_dists, label_ids)
                label_dists_pred = torch.nn.Softmax(dim=-1)(logits)
                label_dists_pred_wo_n = (label_dists_pred / label_dists_pred[:, 1:].sum(dim=-1, keepdim=True))[:, 1:]
                
                wo_n_select = (copy.deepcopy(label_ids) != 0)
                num_batch_items = input_ids.size(0)
                num_batch_items_wo_n = int(wo_n_select.sum().item())
                
                std_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred), label_ids).item()
                wo_n_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred_wo_n[wo_n_select]), label_ids[wo_n_select] - 1).item()
                
            logits = logits.detach().cpu().numpy()
            label_ids = label_ids.to('cpu').numpy()
            
            logits_list += [int(x) for x in np.argmax(logits, axis=1)]
            logits_raw_list += [[float(item) for item in row] for row in logits]
            label_ids_list += [int(x) for x in label_ids]
            
            cur_accuracy = metrics.accuracy_score(label_ids_list, logits_list)
            cur_macro_f1 = metrics.f1_score(label_ids_list, logits_list, average='macro')

            eval_loss += loss.mean().item()
            nb_eval_steps += 1
            nb_eval_examples += input_ids.size(0)
            nb_eval_examples_wo_n += int(wo_n_select.sum().item())
            
            eval_loss_ce += std_ce
            eval_loss_ce_wo_n += wo_n_ce

        eval_loss = eval_loss / nb_eval_steps
        eval_loss_ce = eval_loss_ce / nb_eval_examples
        eval_loss_ce_wo_n = eval_loss_ce_wo_n / nb_eval_examples_wo_n
        
        result = {'eval_loss': eval_loss,
                  'eval_loss_ce': eval_loss_ce,
                  'eval_loss_ce_wo_n': eval_loss_ce_wo_n,
                  'eval_accuracy': cur_accuracy,
                  'eval_macro_f1': cur_macro_f1}

        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(result[key]))
        
        with open(str(args.output_dir) + '/eval_reasoning_epoch-%d.log' % epoch, 'w', encoding='utf-8') as f:
            for key in result:
                f.write(f'{key}: {result[key]}\n')
        
        with open(str(args.output_dir) + '/eval_reasoning_epoch-%d.txt' % epoch, 'w', encoding='utf-8') as f:
            for real_label, pred_label, logits_raw in zip(label_ids_list, logits_list, logits_raw_list):
                logits_raw = [math.exp(item) for item in logits_raw]
                logits_sum = sum(logits_raw)
                logits_raw = [str(item / logits_sum) for item in logits_raw]
                f.write('%d\t%d\t%s\n' % (int(real_label), int(pred_label), '\t'.join(logits_raw)))
        
        
        logging.info("** ** * Epoch: %d, Percent: %d%%, Saving fine-tuned model ** ** * " % (epoch, 100))
        model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
        output_model_file = args.output_dir / ("model_epoch-%d_percent-%.2f_loss-%.5f_loss-%.5f_accuracy-%.2f_ce-%.5f-%.5f.bin" % (epoch, 1.0, mean_loss, eval_loss, 100 * cur_accuracy, eval_loss_ce, eval_loss_ce_wo_n))
        # torch.save(model_to_save.state_dict(), str(output_model_file))
        with open(str(output_model_file), 'wb') as f:
            pass
        
        
        # eval
        model.eval()
        
        eval_loss = 0
        nb_eval_steps = 0
        nb_eval_examples = 0
        nb_eval_examples_wo_n = 0
        
        eval_loss_ce = 0
        eval_loss_ce_wo_n = 0
        
        logits_list = []
        logits_raw_list = []
        label_ids_list = []

        for input_ids, input_mask, label_dists, label_ids in tqdm(test_dataloader, desc="Evaluating"):
            input_ids = input_ids.to(device)
            input_mask = input_mask.to(device)
            label_dists = label_dists.to(device)
            label_ids = label_ids.to(device)

            with torch.no_grad():
                loss, logits = model(input_ids, input_mask, label_dists, label_ids)
                label_dists_pred = torch.nn.Softmax(dim=-1)(logits)
                label_dists_pred_wo_n = (label_dists_pred / label_dists_pred[:, 1:].sum(dim=-1, keepdim=True))[:, 1:]
                
                wo_n_select = (copy.deepcopy(label_ids) != 0)
                num_batch_items = input_ids.size(0)
                num_batch_items_wo_n = int(wo_n_select.sum().item())
                
                std_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred), label_ids).item()
                wo_n_ce = torch.nn.NLLLoss(reduction='sum')(torch.log(label_dists_pred_wo_n[wo_n_select]), label_ids[wo_n_select] - 1).item()
                
            logits = logits.detach().cpu().numpy()
            label_ids = label_ids.to('cpu').numpy()
            
            logits_list += [int(x) for x in np.argmax(logits, axis=1)]
            logits_raw_list += [[float(item) for item in row] for row in logits]
            label_ids_list += [int(x) for x in label_ids]
            
            cur_accuracy = metrics.accuracy_score(label_ids_list, logits_list)
            cur_macro_f1 = metrics.f1_score(label_ids_list, logits_list, average='macro')

            eval_loss += loss.mean().item()
            nb_eval_steps += 1
            nb_eval_examples += input_ids.size(0)
            nb_eval_examples_wo_n += int(wo_n_select.sum().item())
            
            eval_loss_ce += std_ce
            eval_loss_ce_wo_n += wo_n_ce

        eval_loss = eval_loss / nb_eval_steps
        eval_loss_ce = eval_loss_ce / nb_eval_examples
        eval_loss_ce_wo_n = eval_loss_ce_wo_n / nb_eval_examples_wo_n
        
        result = {'eval_loss': eval_loss,
                  'eval_loss_ce': eval_loss_ce,
                  'eval_loss_ce_wo_n': eval_loss_ce_wo_n,
                  'eval_accuracy': cur_accuracy,
                  'eval_macro_f1': cur_macro_f1}

        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(result[key]))
        
        with open(str(args.output_dir_test) + '/eval_reasoning_epoch-%d.log' % epoch, 'w', encoding='utf-8') as f:
            for key in result:
                f.write(f'{key}: {result[key]}\n')
        
        with open(str(args.output_dir_test) + '/eval_reasoning_epoch-%d.txt' % epoch, 'w', encoding='utf-8') as f:
            for real_label, pred_label, logits_raw in zip(label_ids_list, logits_list, logits_raw_list):
                logits_raw = [math.exp(item) for item in logits_raw]
                logits_sum = sum(logits_raw)
                logits_raw = [str(item / logits_sum) for item in logits_raw]
                f.write('%d\t%d\t%s\n' % (int(real_label), int(pred_label), '\t'.join(logits_raw)))
        
        
        logging.info("** ** * Epoch: %d, Percent: %d%%, Saving fine-tuned model ** ** * " % (epoch, 100))
        model_to_save = model.module if hasattr(model, 'module') else model  # Only save the model it-self
        output_model_file = args.output_dir_test / ("model_epoch-%d_percent-%.2f_loss-%.5f_loss-%.5f_accuracy-%.2f_ce-%.5f-%.5f.bin" % (epoch, 1.0, mean_loss, eval_loss, 100 * cur_accuracy, eval_loss_ce, eval_loss_ce_wo_n))
        # torch.save(model_to_save.state_dict(), str(output_model_file))
        with open(str(output_model_file), 'wb') as f:
            pass
        


if __name__ == '__main__':
    # import ipdb
    # ipdb.set_trace()
    main()
