import math
import copy
from os import openpty
from pickle import NONE
from numpy.core.fromnumeric import shape
from numpy.lib.function_base import average
import torch
from torch._C import device
import torch.nn as nn
import torch.nn.functional as F
from typing_extensions import final
from transformers import BertConfig, BertModel, BertTokenizer
import argparse
from torch.autograd import Variable
import numpy as np
import random
import os
import logging
import time

def time_since(start_time):
    return time.time()-start_time

class NTM(nn.Module):
    def __init__(self, opt, hidden_dim=500, l1_strength=0.001):
        super(NTM, self).__init__()
        self.opt = opt
        self.input_dim = opt.bow_vocab_size
        self.topic_num = opt.topic_num
        self.emo_dim = opt.polarities_dim
        topic_num = opt.topic_num
        self.fc11 = nn.Linear(self.input_dim, hidden_dim)
        self.fc12 = nn.Linear(hidden_dim, hidden_dim)
        self.fc21 = nn.Linear(hidden_dim, topic_num)
        self.fc22 = nn.Linear(hidden_dim, topic_num)
        self.fcs = nn.Linear(self.input_dim, hidden_dim, bias=False)

        self.fcg1 = nn.Linear(topic_num, topic_num)
        self.fcg2 = nn.Linear(topic_num, topic_num)
        self.fcg3 = nn.Linear(topic_num, topic_num)
        self.fcg4 = nn.Linear(topic_num, topic_num)
        self.fcd1 = nn.Linear(topic_num, self.input_dim)

        if opt.ntm_with_emo:
            self.fce1 = nn.Linear(topic_num, topic_num)
            self.fce2 = nn.Linear(topic_num, topic_num)
            self.fce3 = nn.Linear(topic_num, topic_num)
            self.fce4 = nn.Linear(topic_num, topic_num)
            self.fcd2 = nn.Linear(topic_num, self.emo_dim)

        self.l1_strength = torch.FloatTensor([l1_strength]).to(opt.device)

    def encode(self, x):
        # print(self.fc11(x))
        e1 = F.relu(self.fc11(x))
        e1 = F.relu(self.fc12(e1))
        e1 = e1.add(self.fcs(x))
        return self.fc21(e1), self.fc22(e1)

    def reparameterize(self, mu, logvar):       
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return eps.mul(std).add_(mu)

    def generate(self, h):
        g1 = torch.tanh(self.fcg1(h))
        g1 = torch.tanh(self.fcg2(g1))
        g1 = torch.tanh(self.fcg3(g1))
        g1 = torch.tanh(self.fcg4(g1))
        g1 = g1.add(h)
        return g1

    def emo_cls(self, h):
        e1 = torch.tanh(self.fce1(h))
        e1 = torch.tanh(self.fce2(e1))
        e1 = torch.tanh(self.fce3(e1))
        e1 = torch.tanh(self.fce4(e1))
        e1 = e1.add(h)
        e1 = F.softmax(self.fcd2(e1), dim=1)
        return e1

    def decode(self, z):
        d1 = F.softmax(self.fcd1(z), dim=1)
        return d1

    def forward(self, x):
        mu, logvar = self.encode(x.view(-1, self.input_dim))
        z = self.reparameterize(mu, logvar)
        g = self.generate(z)
        if self.opt.ntm_with_emo:
            # logits = F.softmax(self.fcd2(z), dim=1)
            logits = self.emo_cls(z)
            return z, g, logits, self.decode(g), mu, logvar
        return z, g, self.decode(g), mu, logvar

    def print_topic_words(self, vocab_dic, fn, n_top_words=20):
        beta_exp = self.fcd1.weight.data.cpu().numpy().T
        logging.info("Writing to %s" % fn)
        fw = open(fn, 'w')
        for k, beta_k in enumerate(beta_exp):
            topic_words = [vocab_dic[w_id] for w_id in np.argsort(beta_k)[:-n_top_words - 1:-1]]
            print('Topic {}: {}'.format(k, ' '.join(topic_words)))
            fw.write('{}\n'.format(' '.join(topic_words)))
        fw.close()

class NTM_V2(nn.Module):
    def __init__(self, opt, hidden_dim=500, l1_strength=0.001):
        super(NTM_V2, self).__init__()
        self.opt = opt
        self.input_dim = opt.bow_vocab_size
        self.topic_num = opt.topic_num
        self.emo_dim = opt.polarities_dim
        topic_num = opt.topic_num
        self.fc11 = nn.Linear(self.input_dim, hidden_dim)
        self.fc12 = nn.Linear(hidden_dim, hidden_dim)
        self.fc21 = nn.Linear(hidden_dim, topic_num)
        self.fc22 = nn.Linear(hidden_dim, topic_num)
        self.fcs = nn.Linear(self.input_dim, hidden_dim, bias=False)

        self.topic_embedding = nn.Linear(opt.topic_num, 768)

        self.emo_cls = nn.Linear(768, self.emo_dim)
        self.bow_cls = nn.Linear(768, self.input_dim)

        self.l1_strength = torch.FloatTensor([l1_strength]).to(opt.device)

    def encode(self, x):
        e1 = F.relu(self.fc11(x))
        e1 = F.relu(self.fc12(e1))
        e1 = e1.add(self.fcs(x))
        return self.fc21(e1), self.fc22(e1)

    def reparameterize(self, mu, logvar):
        if self.training:
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            return eps.mul(std).add_(mu)
        else:
            return mu

    def forward(self, x):
        mu, logvar = self.encode(x.view(-1, self.input_dim))
        z = self.reparameterize(mu, logvar)
        theta = nn.functional.softmax(z, dim=-1)
        topic_vector = self.topic_embedding(theta)
        if self.opt.ntm_with_emo:
            logits = F.softmax(self.emo_cls(topic_vector), dim=-1)
            return z, logits, F.softmax(self.bow_cls(topic_vector), dim=-1), mu, logvar
        return topic_vector, F.softmax(self.emo_cls(topic_vector), dim=-1)

    def print_topic_words(self, vocab_dic, fn, n_top_words=20):
        beta_exp = self.bow_cls.weight.data.cpu().numpy().T
        logging.info("Writing to %s" % fn)
        fw = open(fn, 'w')
        for k, beta_k in enumerate(beta_exp):
            topic_words = [vocab_dic[w_id] for w_id in np.argsort(beta_k)[:-n_top_words - 1:-1]]
            print('Topic {}: {}'.format(k, ' '.join(topic_words)))
            fw.write('{}\n'.format(' '.join(topic_words)))
        fw.close()

class NTM_V2_1(nn.Module):
    def __init__(self, opt, hidden_dim=500, l1_strength=0.001):
        super(NTM_V2_1, self).__init__()
        self.opt = opt
        self.input_dim = opt.bow_vocab_size
        self.topic_num = opt.topic_num
        self.emo_dim = opt.polarities_dim
        topic_num = opt.topic_num
        self.fc11 = nn.Linear(self.input_dim, hidden_dim)
        self.fc12 = nn.Linear(hidden_dim, hidden_dim)
        self.fc21 = nn.Linear(hidden_dim, topic_num)
        self.fc22 = nn.Linear(hidden_dim, topic_num)
        self.fcs = nn.Linear(self.input_dim, hidden_dim, bias=False)

        self.topic_embedding = nn.Parameter(torch.randn([self.topic_num, opt.topic_vector_dim], dtype=torch.float32, device=opt.device))
        self.topic2emo = nn.Parameter(torch.randn([opt.topic_vector_dim, self.emo_dim], dtype=torch.float32, device=opt.device))
        self.topic2bow = nn.Parameter(torch.randn([opt.topic_vector_dim, self.input_dim], dtype=torch.float32, device=opt.device))

        self.l1_strength = torch.FloatTensor([l1_strength]).to(opt.device)

    def encode(self, x):
        e1 = F.relu(self.fc11(x))
        e1 = F.relu(self.fc12(e1))
        e1 = e1.add(self.fcs(x))
        return self.fc21(e1), self.fc22(e1)

    def reparameterize(self, mu, logvar):
        if self.training:
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            return eps.mul(std).add_(mu)
        else:
            return mu

    def forward(self, x):
        mu, logvar = self.encode(x.view(-1, self.input_dim))
        z = self.reparameterize(mu, logvar)
        theta = F.softmax(z, dim=-1).unsqueeze(1)

        topic_emo = F.softmax(torch.matmul(self.topic_embedding, self.topic2emo), dim=-1)
        emo_logits = torch.matmul(theta, topic_emo).squeeze(1)

        topic_bow = F.softmax(torch.matmul(self.topic_embedding, self.topic2bow), dim=-1)
        bow_logits = torch.matmul(theta, topic_bow).squeeze(1)

        return theta, emo_logits, bow_logits, mu, logvar

        if self.opt.ntm_with_emo:
            logits = F.softmax(self.emo_cls(topic_vector), dim=-1)
            return z, logits, F.softmax(self.bow_cls(topic_vector), dim=-1), mu, logvar
        return topic_vector, F.softmax(self.emo_cls(topic_vector), dim=-1)

    def print_topic_words(self, vocab_dic, fn, n_top_words=20):
        beta_exp = torch.matmul(self.topic_embedding, self.topic2bow).data.cpu().numpy()
        logging.info("Writing to %s" % fn)
        fw = open(fn, 'w')
        for k, beta_k in enumerate(beta_exp):
            topic_words = [vocab_dic[w_id] for w_id in np.argsort(beta_k)[:-n_top_words - 1:-1]]
            print('Topic {}: {}'.format(k, ' '.join(topic_words)))
            fw.write('{}\n'.format(' '.join(topic_words)))
        fw.close()

class NTM_V2_2(nn.Module):
    def __init__(self, opt, embedding_matrix, hidden_dim=500, l1_strength=0.001):
        super(NTM_V2_2, self).__init__()
        self.opt = opt
        self.input_dim = opt.bow_vocab_size
        self.topic_num = opt.topic_num
        self.emo_dim = opt.polarities_dim
        topic_num = opt.topic_num
        self.fc11 = nn.Linear(self.input_dim, hidden_dim)
        self.fc12 = nn.Linear(hidden_dim, hidden_dim)
        self.fc21 = nn.Linear(hidden_dim, topic_num)
        self.fc22 = nn.Linear(hidden_dim, topic_num)
        self.fcs = nn.Linear(self.input_dim, hidden_dim, bias=False)

        self.topic_embedding = nn.Parameter(torch.randn([self.topic_num, opt.topic_vector_dim], dtype=torch.float32, device=opt.device))
        self.topic2emo = nn.Parameter(torch.randn([opt.topic_vector_dim, self.emo_dim], dtype=torch.float32, device=opt.device))
        self.topic2bow = nn.Parameter(torch.tensor(embedding_matrix, dtype=torch.float32, device=opt.device).transpose(0, 1))

        self.l1_strength = torch.FloatTensor([l1_strength]).to(opt.device)

    def encode(self, x):
        e1 = F.relu(self.fc11(x))
        e1 = F.relu(self.fc12(e1))
        e1 = e1.add(self.fcs(x))
        return self.fc21(e1), self.fc22(e1)

    def reparameterize(self, mu, logvar):
        if self.training:
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            return eps.mul(std).add_(mu)
        else:
            return mu

    def forward(self, x):
        mu, logvar = self.encode(x.view(-1, self.input_dim))
        z = self.reparameterize(mu, logvar)
        theta = F.softmax(z, dim=-1).unsqueeze(1)

        topic_emo = F.softmax(torch.matmul(self.topic_embedding, self.topic2emo), dim=-1)
        emo_logits = torch.matmul(theta, topic_emo).squeeze(1)

        topic_bow = F.softmax(torch.matmul(self.topic_embedding, self.topic2bow), dim=-1)
        bow_logits = torch.matmul(theta, topic_bow).squeeze(1)

        return theta, emo_logits, bow_logits, mu, logvar

        if self.opt.ntm_with_emo:
            logits = F.softmax(self.emo_cls(topic_vector), dim=-1)
            return z, logits, F.softmax(self.bow_cls(topic_vector), dim=-1), mu, logvar
        return topic_vector, F.softmax(self.emo_cls(topic_vector), dim=-1)

    def print_topic_words(self, vocab_dic, fn, n_top_words=20):
        beta_exp = torch.matmul(self.topic_embedding, self.topic2bow).data.cpu().numpy()
        logging.info("Writing to %s" % fn)
        fw = open(fn, 'w')
        for k, beta_k in enumerate(beta_exp):
            topic_words = [vocab_dic[w_id] for w_id in np.argsort(beta_k)[:-n_top_words - 1:-1]]
            print('Topic {}: {}'.format(k, ' '.join(topic_words)))
            fw.write('{}\n'.format(' '.join(topic_words)))
        fw.close()

def loss_function_cls(logits, targets):
    EMO = F.binary_cross_entropy(logits, targets, size_average=False)
    return EMO

def loss_function_emo(logits, targets, recon_x, x, mu, logvar, criterion):
    EMO = F.binary_cross_entropy(logits, targets, size_average=False)
    BCE = F.binary_cross_entropy(recon_x, x, size_average=False)
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return 0.005 * (BCE + KLD) + EMO, BCE + KLD, EMO

def loss_function(recon_x, x, mu, logvar):
    BCE = F.binary_cross_entropy(recon_x, x, size_average=False)
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return BCE + KLD

def l1_penalty(para):
    return nn.L1Loss()(para, torch.zeros_like(para))

def check_sparsity(para, sparsity_threshold=1e-3):
    num_weights = para.shape[0] * para.shape[1]
    num_zero = (para.abs() < sparsity_threshold).sum().float()
    return num_zero / float(num_weights)

def update_l1(cur_l1, cur_sparsity, sparsity_target):
    diff = sparsity_target - cur_sparsity
    cur_l1.mul_(2.0 ** diff)

def train_ntm_one_epoch(model, boe_model, dataloader, optimizer, opt, epoch, criterion, logger):
    model.train()
    train_loss = 0
    for batch_idx, batch in enumerate(dataloader):
        data_bow = batch['bow_batch'].to(opt.device)
        emo_targets = batch['boe_batch'].to(opt.device)
        # normalize data
        data_bow_norm = F.normalize(data_bow)
        
        if opt.ntm_with_emo:
            if opt.ntm_version == 'v2':
                _, logits, recon_batch, mu, logvar = model(data_bow_norm)
            elif opt.ntm_version == 'v2_1':
                _, logits, recon_batch, mu, logvar = model(data_bow_norm)
            elif opt.ntm_version == 'v2_2':
                _, logits, recon_batch, mu, logvar = model(data_bow_norm)
            else:
                _, _, logits, recon_batch, mu, logvar = model(data_bow_norm)
            loss, rec_loss, emo_loss = loss_function_emo(logits, emo_targets, recon_batch, data_bow, mu, logvar, criterion)
        
        elif opt.ntm_emo_cls:
            logits, _, _ = boe_model(data_bow_norm)
            loss = loss_function_cls(logits, emo_targets)
        else:
            _, _, recon_batch, mu, logvar = model(data_bow_norm) 
            loss = loss_function(recon_batch, data_bow, mu, logvar)
        
        if opt.ntm_emo_cls is not True:
            if opt.ntm_version == 'v2':
                loss = loss + model.l1_strength * l1_penalty(model.bow_cls.weight)
            else:
                loss = loss + model.l1_strength * l1_penalty(torch.matmul(model.topic_embedding, model.topic2bow))
        
        if opt.fp16:
            from apex import amp
            with amp.scale_loss(loss, optimizer) as scaled_loss:
                scaled_loss.backward()
        else:
            loss.backward() 
        
        if opt.fp16:
            torch.nn.utils.clip_grad_norm_(amp.master_params(optimizer), opt.max_grad_norm)
        else:
            if opt.ntm_emo_cls:
                torch.nn.utils.clip_grad_norm_(boe_model.parameters(), opt.max_grad_norm)
            else:
                torch.nn.utils.clip_grad_norm_(model.parameters(), opt.max_grad_norm)

        train_loss += loss.item()
        optimizer.step()
        model.zero_grad()
        if opt.ntm_emo_cls:
            if batch_idx % 100 == 0:
                print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                        epoch, batch_idx * len(data_bow), len(dataloader.dataset),
                               100. * batch_idx / len(dataloader),
                               loss.item() / len(data_bow)))
        else:
            if opt.ntm_with_emo:
                if batch_idx % 100 == 0:
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tRec_loss: {:.6f}\tEmo_loss: {:.6f}'.format(
                        epoch, batch_idx * len(data_bow), len(dataloader.dataset),
                               100. * batch_idx / len(dataloader),
                               loss.item() / len(data_bow), rec_loss.item() / len(data_bow), emo_loss.item() / len(data_bow)))
            else:
                if batch_idx % 100 == 0:
                    print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\t'.format(
                        epoch, batch_idx * len(data_bow), len(dataloader.dataset),
                               100. * batch_idx / len(dataloader),
                               loss.item() / len(data_bow)))

    logger.info('====>Train epoch: {} Average loss: {:.4f}'.format(
        epoch, train_loss / len(dataloader.dataset)))
    if opt.ntm_version == 'v2':
        sparsity = check_sparsity(model.bow_cls.weight.data)
    else:
        sparsity = check_sparsity(torch.matmul(model.topic_embedding, model.topic2bow).data)
    logger.info("Overall sparsity = %.3f, l1 strength = %.5f" % (sparsity, model.l1_strength))
    logger.info("Target sparsity = %.3f" % opt.target_sparsity)
    update_l1(model.l1_strength, sparsity, opt.target_sparsity)
    return sparsity

def test_ntm_one_epoch(model, boe_model, dataloader, opt, epoch, criterion, logger):
    model.eval()
    test_loss = 0
    rec_loss = 0
    emo_loss = 0
    with torch.no_grad():
        for i, batch in enumerate(dataloader):
            data_bow = batch['bow_batch'].to(opt.device)
            emo_targets = batch['boe_batch'].to(opt.device)
            data_bow_norm = F.normalize(data_bow)
            if opt.ntm_with_emo:
                if opt.ntm_version == 'v2':
                    _, logits, recon_batch, mu, logvar = model(data_bow_norm)
                elif opt.ntm_version == 'v2_1':
                    _, logits, recon_batch, mu, logvar = model(data_bow_norm)
                elif opt.ntm_version == 'v2_2':
                    _, logits, recon_batch, mu, logvar = model(data_bow_norm)
                else:
                    _, _, logits, recon_batch, mu, logvar = model(data_bow_norm)
                test, rec, emo = loss_function_emo(logits, emo_targets, recon_batch, data_bow, mu, logvar, criterion)
                rec_loss += rec.item()
                emo_loss += emo.item()
            elif opt.ntm_emo_cls:
                logits, _, _ = boe_model(data_bow_norm)
                test = loss_function_cls(logits, emo_targets)
            else:
                _, _, recon_batch, mu, logvar = model(data_bow_norm)
                test = loss_function(recon_batch, data_bow, mu, logvar)
            
            test_loss += test.item()
            
    if opt.ntm_with_emo:
        rec_loss = rec_loss / len(dataloader.dataset)
        emo_loss = emo_loss / len(dataloader.dataset)
        avg_loss = test_loss / len(dataloader.dataset)
        logger.info('====> Test epoch: {} Average loss:  {:.4f} Average rec_loss:  {:.4f} Average emo_loss:  {:.4f}'.format(epoch, avg_loss, rec_loss, emo_loss))
    else:
        avg_loss = test_loss / len(dataloader.dataset)
        logger.info('====> Test epoch: {} Average loss:  {:.4f}'.format(epoch, avg_loss))
    return avg_loss

def train_ntm_model(opt, logger, ntm_model, boe_model, train_data_loader, test_data_loader, bow_dictionary, optimizer_ntm, criterion):
        logger.info('======================  Start NTM Training  =========================')

        if opt.only_train_ntm or (opt.use_topic_represent and not opt.load_pretrain_ntm):
            logger.info("\nWarming up ntm for %d epochs" % opt.ntm_warm_up_epochs)
            min_val_loss = 10000
            continue_not_increase = 0
            for epoch in range(1, opt.ntm_warm_up_epochs + 1):
                if opt.ntm_emo_cls:
                    increase_flag = False
                sparsity = train_ntm_one_epoch(ntm_model, boe_model, train_data_loader, optimizer_ntm, opt, epoch, criterion, logger)
                val_loss = test_ntm_one_epoch(ntm_model, boe_model, test_data_loader, opt, epoch, criterion, logger)
                
                # if val_loss < min_val_loss:
                #     min_val_loss = val_loss
                #     increase_flag = True
                # if epoch % 10 == 0:
                #     ntm_model.print_topic_words(bow_dictionary, os.path.join(opt.save_path, 'topwords_e%d_ntm_model_v2_1_weibo_1e3.txt' % epoch))

                if opt.save:
                    if opt.ntm_emo_cls:
                        if val_loss < min_val_loss:
                            increase_flag = True
                            min_val_loss = val_loss
                            best_boe_model_path = os.path.join(opt.save_path, 'boe_topic' + str(opt.topic_num) + '_soft_label')
                            logger.info("\nSaving boe model into %s" % best_boe_model_path)
                            torch.save(boe_model.state_dict(), open(best_boe_model_path, 'wb'))
                    else:
                        if epoch % 10 == 0:
                            ntm_model.print_topic_words(bow_dictionary, os.path.join(opt.save_path, 'topwords_e%d_ntm_model_v2_1_douban_topic%d.txt' % (epoch, opt.topic_num)))
                            best_ntm_model_path = os.path.join(opt.save_path, 'e%d.val_loss=%.3f.sparsity=%.3f.ntm_model_v2_1_douban_topic%d' %
                                                               (epoch, val_loss, sparsity, opt.topic_num))
                            logger.info("\nSaving warm up ntm model into %s" % best_ntm_model_path)
                            torch.save(ntm_model.state_dict(), open(best_ntm_model_path, 'wb'))
                if opt.ntm_emo_cls:
                    if increase_flag == False:
                        continue_not_increase += 1
                        if continue_not_increase >= 5:
                            logger.info('early stop.')
                            break
                    else:
                        continue_not_increase = 0 

        elif opt.use_topic_represent:
            print("Loading ntm model from %s" % opt.check_pt_ntm_model_path)
            ntm_model.load_state_dict(torch.load(opt.check_pt_ntm_model_path))