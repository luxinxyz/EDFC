import math
import copy
from os import openpty
from pickle import NONE
from numpy.core.fromnumeric import shape
from numpy.lib.function_base import average
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing_extensions import final
from transformers import BertConfig, BertModel, BertTokenizer
import argparse
from torch.autograd import Variable
import numpy as np
import random
import os
import logging
from models.ntm import NTM

class LayerNorm(nn.Module):
    def __init__(self, config, variance_epsilon=1e-12):
        super(LayerNorm, self).__init__()
        self.gamma = nn.Parameter(torch.ones(config.topic_num))
        self.beta = nn.Parameter(torch.zeros(config.topic_num))
        self.variance_epsilon = variance_epsilon

    def forward(self, x):
        u = x.mean(-1, keepdim=True)
        s = (x - u).pow(2).mean(-1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.variance_epsilon)
        return self.gamma * x + self.beta

class BOE(nn.Module):
    def __init__(self, opt):
        super(BOE, self).__init__()
        self.opt = opt
        self.input_dim = opt.bow_vocab_size
        self.topic_num = opt.topic_num
        self.emo_dim = opt.polarities_dim
        topic_num = opt.topic_num
        
        self.ntm = NTM(opt)
        if opt.ntm_emo_cls:
            if opt.topic_num == 40:
                self.ntm.load_state_dict(torch.load('./state_dict/e100.val_loss=198.012.sparsity=0.846.ntm_model_topic40'))
            elif opt.topic_num == 30:
                self.ntm.load_state_dict(torch.load('./state_dict/e100.val_loss=198.502.sparsity=0.851.ntm_model_topic30'))
            elif opt.topic_num == 60:
                self.ntm.load_state_dict(torch.load('./state_dict/e100.val_loss=197.454.sparsity=0.849.ntm_model_topic60'))
            else:
                self.ntm.load_state_dict(torch.load('./state_dict/e100.val_loss=198.700.sparsity=0.847.ntm_model_topic50_new_data_sbatch'))
        # for _, p in self.ntm.named_parameters():
        #     p.requires_grad = False
        # self.layernorm = LayerNorm(opt)
        if opt.use_emo_mlp:
            self.fce1 = nn.Linear(topic_num, topic_num)
            self.fce2 = nn.Linear(topic_num, topic_num)
            self.fce3 = nn.Linear(topic_num, topic_num)
            self.fce4 = nn.Linear(topic_num, topic_num)
        self.fcd2 = nn.Linear(topic_num, self.emo_dim)

    def emo_cls(self, h):
        # e1 = self.fce1(h)
        # # print('1', e1[0])   
        # e1 = self.layernorm(self.fce2(e1))
        # # print('2', e1[0])
        # e1 = self.fce3(e1)
        # # print('3', e1[0])
        # e1 = self.layernorm(self.fce4(e1))
        # # print('4', e1[0])
        e1 = torch.tanh(self.fce1(h))
        e1 = torch.tanh(self.fce2(e1))  
        e1 = torch.tanh(self.fce3(e1))
        e1 = torch.tanh(self.fce4(e1))
        # e1 = torch.tanh(self.fce1(h))
        # e1 = torch.tanh(self.layernorm(self.fce2(e1)))
        # e1 = torch.tanh(self.fce3(e1))
        # e1 = torch.tanh(self.layernorm(self.fce4(e1)))
        e1 = e1.add(h)
        # e1 = self.layernorm(e1)
        if self.opt.use_emo_vector:
            return e1    
        e1 = F.softmax(self.fcd2(e1), dim=1)
        return e1

    def forward(self, x):
        z, g, _, _, _ = self.ntm(x)
        topic = F.softmax(g, dim=1)
        if self.opt.use_emo_mlp:
            if self.opt.use_emo_vector:
                if self.opt.topic_type == 'z':
                    emo_vector = self.emo_cls(z)
                else:
                    emo_vector = self.emo_cls(g)
                return emo_vector, topic, g
            if self.opt.topic_type == 'z':
                logits = self.emo_cls(z)
            else:
                logits = self.emo_cls(g)
            return logits, topic, g
        else:
            logits = self.fcd2(z)
            return F.softmax(logits, dim=1), topic, g