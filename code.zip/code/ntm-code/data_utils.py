# -*- coding: utf-8 -*-

import os
import pickle
import numpy as np
from transformers import BertTokenizer
from transformers import GPT2Tokenizer
import torch
import torch.utils.data as data
from tqdm import tqdm


def load_word_vec(path, word2idx=None, embed_dim=300):
    fin = open(path, 'r', encoding='utf-8', newline='\n', errors='ignore')
    word_vec = {}
    for line in fin:
        tokens = line.rstrip().split()
        word, vec = ' '.join(tokens[:-embed_dim]), tokens[-embed_dim:]
        if word in word2idx.keys():
            word_vec[word] = np.asarray(vec, dtype='float32')
    return word_vec


def build_embedding_matrix(word2idx, embed_dim):
    embedding_matrix_file_name = './middle_var/{0}_embedding_matrix.pkl'.format(str(embed_dim))
    if os.path.exists(embedding_matrix_file_name):
        print('loading embedding_matrix:', embedding_matrix_file_name)
        embedding_matrix = pickle.load(open(embedding_matrix_file_name, 'rb'))
    else:
        print('loading word vectors ...')
        embedding_matrix = np.zeros((len(word2idx), embed_dim))  # idx 0 and 1 are all-zeros
        embedding_matrix[:, :] = np.random.uniform(-1/np.sqrt(embed_dim), 1/np.sqrt(embed_dim), (1, embed_dim))
        fname = '/users6/wxzhao/nlp_res/tencent/Tencent_AILab_ChineseEmbedding.txt'
        word_vec = load_word_vec(fname, word2idx=word2idx, embed_dim=embed_dim)
        print('building embedding_matrix:', embedding_matrix_file_name)
        for word, i in word2idx.items():
            vec = word_vec.get(word)
            if vec is not None:
                # words not found in embedding index will be all-zeros.
                embedding_matrix[i] = vec
        pickle.dump(embedding_matrix, open(embedding_matrix_file_name, 'wb'))
    return embedding_matrix

class Bert_Tokenizer(object):
    def __init__(self, dataset='douban'):
        if dataset == 'ecg':
            print('Using Ch-BERT')
            self.tokenizer = BertTokenizer.from_pretrained('bert-base-chinese')
        elif dataset == 'douban' or dataset == 'weibo':
            print('Using Ch-BERT')
            # self.tokenizer = BertTokenizer.from_pretrained('hfl/chinese-roberta-wwm-ext-large')
            # self.tokenizer = BertTokenizer.from_pretrained('./chinese_roberta_wwm_ext_pytorch')      
            self.tokenizer = BertTokenizer(vocab_file='./chinese_roberta_wwm_ext_pytorch/vocab.txt')
            print(len(self.tokenizer.vocab))
        else:
            print('Using En-BERT')
            self.tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

    def text_to_sequence(self, text, tran=True):
        text = text.lower()
        words = text.split()
        if tran==False:
            unknownidx = 1
            sequence = [self.word2idx[w] if w in self.word2idx else unknownidx for w in words]
            if len(sequence) == 0:
                sequence = [0]
            return sequence
        else:
            trans = []
            realwords = []
            for word in words:
                wordpieces = self.tokenizer._tokenize(word)
                tmplen = len(realwords)

                realwords.extend(wordpieces)
                trans.append([tmplen, len(realwords)])
            sequence = [self.tokenizer._convert_token_to_id('[CLS]')]+[self.tokenizer._convert_token_to_id(w) for w in realwords]
            if len(sequence) == 0:
                sequence = [0]

            return sequence, trans, realwords

class Tokenizer(object):
    def __init__(self, word2idx=None):
        if word2idx is None:
            self.word2idx = {}
            self.idx2word = {}
            self.idx = 0
            self.word2idx['<pad>'] = self.idx
            self.idx2word[self.idx] = '<pad>'
            self.idx += 1
            self.word2idx['<s>'] = self.idx
            self.idx2word[self.idx] = '<s>'
            self.idx += 1
            self.word2idx['<e>'] = self.idx
            self.idx2word[self.idx] = '<e>'
            self.idx += 1
            self.word2idx['<oov>'] = self.idx
            self.idx2word[self.idx] = '<oov>'
            self.idx += 1
        else:
            self.word2idx = word2idx
            self.idx2word = {v:k for k,v in word2idx.items()}

    def fit_on_text(self, text):
        words = text.split()
        for word in words:
            if word not in self.word2idx:
                self.word2idx[word] = self.idx
                self.idx2word[self.idx] = word
                self.idx += 1

    def text_to_sequence(self, text):
        text = text.lower()
        words = text.split()
        unknownidx = 1
        sequence = [self.word2idx[w] if w in self.word2idx else unknownidx for w in words]
        if len(sequence) == 0:
            sequence = [0]
        return sequence

class ABSADataset(object):
    def __init__(self, data):
        self.data = data

    def __getitem__(self, index):
        return self.data[index]

    def __len__(self):
        return len(self.data)

def load_vocab(vocab_file):
    """Loads a vocabulary file into a dictionary."""
    vocab = collections.OrderedDict()
    with open(vocab_file, "r", encoding="utf-8") as reader:
        tokens = reader.readlines()
    for index, token in enumerate(tokens):
        token = token.rstrip("\n")
        vocab[token] = index
    return vocab

class ABSADatesetReader:
    @staticmethod
    def __read_text__(fnames):
        text = ''
        for fname in fnames:
            fin = open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
            lines = fin.readlines()
            fin.close()
            for i in range(len(lines)):
                post, _, reply = lines[i].strip().split('\t')
                text_raw = post + " " + reply
                text += text_raw + " "
        return text

    @staticmethod
    def __read_data__(fname, tokenizer):
        fin = open(fname, 'r', encoding='utf-8', newline='\n', errors='ignore')
        lines = fin.readlines()
        fin.close()
        all_data = []
        cnt = 0
        if 's2s' not in fname:
            for i in range(0, len(lines)): 
                sen, label, rsp = lines[i].strip().split('\t')
                # response = '[unused0] ' + rsp  # [unused0] stands for the decoding start token [\s]
                # target_response = rsp + ' [unused1]'
                text_indices, _, _ = tokenizer.text_to_sequence(sen, tran=True)
                rsp_indices, _, _ = tokenizer.text_to_sequence(rsp, tran=True)
                tar_rsp_indices, _, word_piece = tokenizer.text_to_sequence(rsp, tran=True)
                rsp_indices.insert(1, 1)
                tar_rsp_indices += [2]
                if len(text_indices) > 512:
                    cnt += 1
                    word_cnt = len(text_indices)
                    text_indices = text_indices[word_cnt-512:]
                polarity = int(label)
                vocab = tokenizer.tokenizer.vocab
                one_hot = torch.zeros(len(vocab))
                for word in word_piece:
                    if one_hot[vocab[word]] == 0:
                        one_hot[vocab[word]] += 1
                data = {
                    'context': sen,
                    'response': rsp,
                    'text_indices': text_indices,
                    'response_indices': rsp_indices,
                    'target_response_indices': tar_rsp_indices,
                    'text_one_hot': one_hot,
                    'polarity': polarity,
                }
                all_data.append(data)
            print("Over 512: ", cnt)
        else:
            for i in range(0, len(lines)): 
                sen, label, rsp = lines[i].strip().split('\t')
                response = '<s> ' + rsp  # [unused0] stands for the decoding start token [\s]
                target_response = rsp + ' <e>'
                text_indices = tokenizer.text_to_sequence(sen)
                rsp_indices = tokenizer.text_to_sequence(response)
                tar_rsp_indices = tokenizer.text_to_sequence(target_response)
                assert(len(rsp_indices) == len(tar_rsp_indices))
                polarity = int(label)
                data = {
                    'context': sen,
                    'response': rsp,
                    'text_indices': text_indices,
                    'response_indices': rsp_indices,
                    'target_response_indices': tar_rsp_indices,
                    'polarity': polarity,
                }
                all_data.append(data)
        return all_data

    def __init__(self, dataset='dialogues'):
        print("preparing {0} dataset ...".format(dataset))
        fname = {
            'dialogues': {
                'train': './ep_datasets/dialogues_train.txt',
                'test': './ep_datasets/dialogues_test.txt'
            },
            'iemocap': {
                'train': './ep_datasets/iemocap_train.txt',
                'test': './ep_datasets/iemocap_test.txt'
            },
            'ecg': {
                'train': './ep_datasets/ecm_train.txt',
                'test': './ep_datasets/ecm_test.txt'
            },
            'ecg_s2s': {
                'train': './ep_datasets/ecm_train_s2s.txt',
                'test': './ep_datasets/ecm_test_s2s.txt'
            }
        }
        if dataset == 'ecg_s2s':
            text = ABSADatesetReader.__read_text__([fname[dataset]['train'], fname[dataset]['test']])
            if os.path.exists('./middle_var/'+dataset+'_word2idx.pkl'):
                print("loading {0} tokenizer...".format(dataset))
                with open('./middle_var/'+dataset+'_word2idx.pkl', 'rb') as f:
                    word2idx = pickle.load(f)
                    self.tokenizer = Tokenizer(word2idx=word2idx)
            else:
                self.tokenizer = Tokenizer()
                self.tokenizer.fit_on_text(text)
                with open(dataset+'_word2idx.pkl', 'wb') as f:
                    pickle.dump(self.tokenizer.word2idx, f)
        else:       
            self.tokenizer = Bert_Tokenizer(dataset)
        
        if(os.path.exists('data/' + dataset + '/dataset_' + dataset + '.p')):
            print("Loading " + dataset + '...')
            with open('data/' + dataset + '/dataset_' + dataset + '.p', "rb") as f:
                [self.train_data, self.test_data] = pickle.load(f)
        else:
            print("Building dataset " + dataset + '...')
            self.train_data = ABSADataset(ABSADatesetReader.__read_data__(fname[dataset]['train'], self.tokenizer))
            self.test_data = ABSADataset(ABSADatesetReader.__read_data__(fname[dataset]['test'], self.tokenizer))
            with open('data/' + dataset + '/dataset_' + dataset + '.p', "wb") as f:
                pickle.dump([self.train_data, self.test_data], f)
                print("Saved PICKLE")

def collate_fn(data):
    def merge(sequences):
        lengths = [len(seq) for seq in sequences]
        padded_seqs = torch.zeros(len(sequences), max(lengths)).long() ## padding index 0
        for i, seq in enumerate(sequences):
            end = lengths[i]
            padded_seqs[i, :end] = seq[:end]
        return padded_seqs 

    def _pad_bow(input_list):
        # bow_vocab = len(self.bow_dictionary)
        res_src_bow = np.zeros((len(input_list), 2000))
        for idx, bow in enumerate(input_list):
            # print(len(bow))
            bow_k = [k for k, _ in bow]
            bow_v = [v for _, v in bow]
            res_src_bow[idx, bow_k] = bow_v
        return torch.FloatTensor(res_src_bow)

    data.sort(key=lambda x: len(x["context_indices"]), reverse=True) ## sort by source seq
    item_info = {}
    for key in data[0].keys():
        item_info[key] = [d[key] for d in data]

    input_batch = merge(item_info['context_indices'])
    response_batch = merge(item_info['response_indices'])
    target_batch = merge(item_info['target_indices'])
    dialog_batch = merge(item_info['dialog_indices'])
    bow_batch = _pad_bow(item_info["bow_seq"])

    input_batch = input_batch.cuda()
    target_batch = target_batch.cuda()
    response_batch = response_batch.cuda()
    dialog_batch = dialog_batch.cuda()
    bow_batch = bow_batch.cuda()
 
    d = {}
    d["input_batch"] = input_batch
    d["response_batch"] = response_batch
    d["target_batch"] = target_batch
    d["dialog_batch"] = dialog_batch
    d["bow_batch"] = bow_batch
    d["emotion"] = item_info['emotion']
    ##text
    d["input_txt"] = item_info['context']
    d["target_txt"] = item_info['target']
    return d 

def collate_fn_douban(data):
    def merge(sequences):
        lengths = [len(seq) for seq in sequences]
        # padded_seqs = torch.zeros(len(sequences), max(lengths)).long() ## padding index 0
        padded_seqs = torch.zeros(len(sequences), 256).long()
        for i, seq in enumerate(sequences):
            end = lengths[i]
            if end <= 256:
                padded_seqs[i, :end] = seq[:end]
            else:
                padded_seqs[i, :] = seq[:256]
        return padded_seqs 

    def _pad_bow(input_list):
        # bow_vocab = len(self.bow_dictionary)
        res_src_bow = np.zeros((len(input_list), 5000)) #98509
        for idx, bow in enumerate(input_list):
            # print(len(bow))
            bow_k = [k for k, _ in bow]
            bow_v = [v for _, v in bow]
            res_src_bow[idx, bow_k] = bow_v
        return torch.FloatTensor(res_src_bow)
    
    def _pad_boe(input_list):
        # bow_vocab = len(self.bow_dictionary)
        res_src_bow = np.zeros((len(input_list), 5)) #98509
        for idx, bow in enumerate(input_list):
            for item in bow:
                res_src_bow[idx][int(item)] = 1
        return torch.FloatTensor(res_src_bow)

    data.sort(key=lambda x: len(x["context_indices"]), reverse=True) ## sort by source seq
    item_info = {}
    for key in data[0].keys():
        item_info[key] = [d[key] for d in data]

    input_batch = merge(item_info['context_indices'])
    bow_batch = _pad_bow(item_info["bow_seq"])
 
    d = {}
    d["input_batch"] = input_batch
    d["emotion"] = item_info['emotion']
    d["context"] = item_info['context']
    d["bow_batch"] = bow_batch

    return d 

class Dataset(data.Dataset):
    """Custom data.Dataset compatible with data.DataLoader."""
    def __init__(self, opt, data, tokenizer, bow_dictionary):
        """Reads source and target sequences from txt files."""
        self.opt = opt
        self.tokenizer = tokenizer
        self.data = data
        self.bow_dictionary = bow_dictionary

    def __len__(self):
        return len(self.data["context"])

    def __getitem__(self, index):
        """Returns one data pair (source and target)."""
        if self.opt.dataset == 'douban' or self.opt.dataset == 'weibo':
            item = {}
            item["context"] = self.data["context"][index]
            item["context_indices"] = self.data["context_indices"][index]
            item['bow_seq'] = self.data["src_bow"][index]
            if self.opt.only_train_ntm:
                item['boe'] = self.data["bom"][index]
            item["emotion"] = [self.data["emotion"][index]]    
        else:
            item = {}
            item["context"], item["target"] = self.data["context"][index], self.data["target"][index]
            item["context_indices"], item["response_indices"], item["target_indices"], item["dialog_indices"] = self.preprocess(self.data["context"][index], self.data["target"][index])
            item['bow_seq'] = self.data["src_bow"][index]
            item["emotion"] = torch.LongTensor([self.data["emotion"][index]])
        return item

    def preprocess(self, context, rsp):
        """Converts words to ids."""
        if self.opt.model_name == 'gpt2':
            text_indices = self.tokenizer(context)['input_ids']
            rsp_indices = [0]
            tar_rsp_indices = [0]
            dialog_indices = [0]
        else:
            dialog_indices, _, _ = self.tokenizer.text_to_sequence(context + rsp, tran=True)
            text_indices, _, _ = self.tokenizer.text_to_sequence(context, tran=True)
            rsp_indices, _, _ = self.tokenizer.text_to_sequence(rsp, tran=True)
            tar_rsp_indices, _, _ = self.tokenizer.text_to_sequence(rsp, tran=True)
            rsp_indices.insert(1, 1)
            tar_rsp_indices += [2]

        if len(text_indices) > 512:
            word_cnt = len(text_indices)
            text_indices = text_indices[word_cnt-512:]
        return torch.LongTensor(text_indices), torch.LongTensor(rsp_indices), torch.LongTensor(tar_rsp_indices), torch.LongTensor(dialog_indices)
    
    def _pad_bow(self, input_list):
        # bow_vocab = len(self.bow_dictionary)
        res_src_bow = np.zeros((len(input_list), len(self.bow_dictionary))) #98509
        for idx, bow in enumerate(input_list):
            # print(len(bow))
            bow_k = [k for k, _ in bow]
            bow_v = [v for _, v in bow]
            res_src_bow[idx, bow_k] = bow_v
        return torch.FloatTensor(res_src_bow)
    
    def _pad_boe(self, input_list):
        # bow_vocab = len(self.bow_dictionary)
        res_src_bow = np.zeros((len(input_list), 5)) #98509
        for idx, bow in enumerate(input_list):
            to_int = [int(i) for i in bow]
            bow = np.array(to_int)
            length = len(bow)
            for i in range(5):
                cnt = sum(bow == i)
                res_src_bow[idx][i] = cnt / length
            # for item in bow:
            #     res_src_bow[idx][int(item)] = 1
        return torch.FloatTensor(res_src_bow)

    def collate_fn_bow(self, batches):

        bow_batch = [b['bow_seq'] for b in batches]
        boe_batch = [b['boe'] for b in batches]
       
        bow_batch = self._pad_bow(bow_batch)
        boe_batch = self._pad_boe(boe_batch)      

        d = {}
        d["bow_batch"] = bow_batch
        d["boe_batch"] = boe_batch      
        return d 

def prepare_data_seq(opt, bow_dictionary, batch_size=32):  
    
    if opt.model_name == 'gpt2':
        tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    else:
        tokenizer = Bert_Tokenizer(opt.dataset)
    
    if opt.only_train_ntm is not True:
        pairs_tra, pairs_val, pairs_tst = load_dataset(opt, bow_dictionary, tokenizer)
    else:
        pairs_tra, pairs_tst = load_dataset(opt, bow_dictionary, tokenizer)

    dataset_train = Dataset(opt, pairs_tra, tokenizer, bow_dictionary)
    if opt.only_train_ntm:
        data_loader_tra = torch.utils.data.DataLoader(dataset=dataset_train,
                                             batch_size=batch_size, num_workers=8,
                                             shuffle=True, collate_fn=dataset_train.collate_fn_bow, pin_memory=True)
    else:
        data_loader_tra = torch.utils.data.DataLoader(dataset=dataset_train,
                                             batch_size=batch_size, num_workers=8,
                                             shuffle=True, collate_fn=collate_fn_douban, pin_memory=True)
    
    if opt.only_train_ntm is not True:
        dataset_valid = Dataset(opt, pairs_val, tokenizer, bow_dictionary)
        if opt.only_train_ntm:
            data_loader_val = torch.utils.data.DataLoader(dataset=dataset_valid,
                                                batch_size=batch_size, num_workers=8,
                                                shuffle=False, collate_fn=dataset_train.collate_fn_bow, pin_memory=True)
        else:
            data_loader_val = torch.utils.data.DataLoader(dataset=dataset_valid,
                                                batch_size=batch_size, num_workers=8,
                                                shuffle=False, collate_fn=collate_fn_douban, pin_memory=True)
    
    dataset_test = Dataset(opt, pairs_tst, tokenizer, bow_dictionary)
    if opt.only_train_ntm:
        data_loader_tst = torch.utils.data.DataLoader(dataset=dataset_test,
                                             batch_size=batch_size, num_workers=8,
                                             shuffle=False, collate_fn=dataset_test.collate_fn_bow, pin_memory=True)
    else:
        data_loader_tst = torch.utils.data.DataLoader(dataset=dataset_test,
                                             batch_size=batch_size, num_workers=8,
                                             shuffle=False, collate_fn=collate_fn_douban, pin_memory=True)

    if opt.only_train_ntm is not True:
        return data_loader_tra, data_loader_val, data_loader_tst
    return data_loader_tra, data_loader_tst
    
def preprocess_douban(context, tokenizer):
    """Converts words to ids."""
    text_indices, _, _ = tokenizer.text_to_sequence(context, tran=True)
    if len(text_indices) > 512:
        word_cnt = len(text_indices)
        text_indices = text_indices[word_cnt-512:]
        text_indices[0] = 101
    # else:
    #     text_indices += [0] * (256 - len(text_indices))
    return torch.tensor(text_indices)

MAX_LEN = 128
def texts_to_ids_and_mask(texts):
    tokenizer = BertTokenizer('./chinese_roberta_wwm_ext_pytorch/vocab.txt', never_split=("[UNK]", "[SEP]", "[PAD]", "[CLS]", "[MASK]"))

    dialog_context_texts = texts
    dialog_context_length = len(dialog_context_texts)
    dialog_context_special_tokens_count = dialog_context_length + 1
    dialog_context_normal_tokens_max_count = MAX_LEN - dialog_context_special_tokens_count
    dialog_context_texts_tokens = [tokenizer.tokenize(text) for text in dialog_context_texts]
    
    turn_index = 0
    while sum([len(x) for x in dialog_context_texts_tokens]) > dialog_context_normal_tokens_max_count:
        if len(dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)]) <= 1:
            turn_index += 1
        else:
            dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)] = dialog_context_texts_tokens[turn_index % len(dialog_context_texts_tokens)][0:-1]
            turn_index += 1
    assert (sum([len(x) for x in dialog_context_texts_tokens]) <= dialog_context_normal_tokens_max_count)
    assert (len(dialog_context_texts) == len(dialog_context_texts_tokens))
    
    dialog_context_tokens = ["[CLS]"]
    for text_tokens in dialog_context_texts_tokens:
        dialog_context_tokens = dialog_context_tokens + text_tokens + ["[SEP]"]

    combine_dialog_context_length = len(dialog_context_tokens)
    combine_dialog_context_token_ids = tokenizer.convert_tokens_to_ids(dialog_context_tokens) + [0 for x in range(MAX_LEN - combine_dialog_context_length)]
    combine_dialog_context_mask = [1 for x in range(combine_dialog_context_length)] + [0 for x in range(MAX_LEN - combine_dialog_context_length)]

    assert (len(combine_dialog_context_token_ids) == MAX_LEN)
    assert (len(combine_dialog_context_mask) == MAX_LEN)
    
    return torch.tensor(combine_dialog_context_token_ids)

def load_dataset(opt, bow_dictionary, tokenizer):
    if opt.only_train_ntm:
        if(os.path.exists('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_topic.p')):
            print("LOADING " + opt.dataset + '_topic')
            with open('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_topic.p', "rb") as f:
                [data_train, data_test] = pickle.load(f)
        else:
            print("Building dataset...")
            data_train = {'context':[], 'target':[], 'emotion':[], 'src_bow':[], 'bom':[], 'context_indices':[]}
            data_test = {'context':[], 'target':[], 'emotion':[], 'src_bow':[], 'bom':[], 'context_indices':[]}
            with open('./data/' + opt.dataset + '/' + opt.dataset + '_topic_train.txt', 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in tqdm(lines):
                    all = line.strip().split('\t')
                    emotion = all[-2]
                    context = ' '.join(all[:-2])
                    target = all[-3]
                    emo_list = all[-1].split(' ')
                    assert(len(all[:-2]) == len(emo_list))
                    data_train['context'].append(context)
                    data_train['emotion'].append(int(emotion))
                    data_train['target'].append(target)
                    data_train['context_indices'].append(preprocess_douban(context, tokenizer))
                    data_train['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
                    data_train['bom'].append(emo_list)
            
            with open('./data/' + opt.dataset + '/' + opt.dataset + '_topic_test.txt', 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in tqdm(lines):
                    all = line.strip().split('\t')
                    emotion = all[-2]
                    context = ' '.join(all[:-2])
                    target = all[-3]
                    emo_list = all[-1].split(' ')
                    assert(len(all[:-2]) == len(emo_list))
                    data_test['context'].append(context)
                    data_test['emotion'].append(int(emotion))
                    data_test['target'].append(target)
                    data_test['context_indices'].append(preprocess_douban(context, tokenizer))
                    data_test['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
                    data_test['bom'].append(emo_list)
            with open('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_topic.p', "wb") as f:
                pickle.dump([data_train, data_test], f)
                print("Saved PICKLE")
    else:
        if(os.path.exists('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_ep.p')):
            print("LOADING " + opt.dataset)
            with open('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_ep.p', "rb") as f:
                [data_train, data_valid, data_test] = pickle.load(f)
        else:
            print("Building ep dataset...")
            data_train = {'context':[], 'target':[], 'emotion':[], 'src_bow':[], 'context_indices':[]}
            data_valid = {'context':[], 'target':[], 'emotion':[], 'src_bow':[], 'context_indices':[]}
            data_test = {'context':[], 'target':[], 'emotion':[], 'src_bow':[], 'context_indices':[]}
            with open('./data/' + opt.dataset + '/' + opt.dataset + '_ep_train.txt', 'r', encoding='utf-8') as f:
                lines = f.readlines()
                if opt.dataset == 'douban':
                    for line in tqdm(lines):
                        all = line.strip().split('\t')
                        emotion = all[-1]
                        context = ' '.join(all[:-1])
                        target = all[-2]
                        data_train['context'].append(context)
                        data_train['emotion'].append(int(emotion))
                        data_train['target'].append(target)
                        # data_train['context_indices'].append(preprocess_douban(context, tokenizer))
                        data_train['context_indices'].append(texts_to_ids_and_mask(all[:-1]))
                        data_train['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
                else:
                    for line in lines:
                        context, emotion, target = line.strip().split('\t')
                        data_train['context'].append(context)
                        data_train['emotion'].append(int(emotion))
                        data_train['target'].append(target)
                        data_train['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
            
            with open('./data/' + opt.dataset + '/' + opt.dataset + '_ep_dev.txt', 'r', encoding='utf-8') as f:
                lines = f.readlines()
                if opt.dataset == 'douban':
                    for line in tqdm(lines):
                        all = line.strip().split('\t')
                        emotion = all[-1]
                        context = ' '.join(all[:-1])
                        target = all[-2]
                        data_valid['context'].append(context)
                        data_valid['emotion'].append(int(emotion))
                        data_valid['target'].append(target)
                        # data_valid['context_indices'].append(preprocess_douban(context, tokenizer))
                        data_valid['context_indices'].append(texts_to_ids_and_mask(all[:-1]))
                        data_valid['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
                else:
                    for line in lines:
                        context, emotion, target = line.strip().split('\t')
                        data_valid['context'].append(context)
                        data_valid['emotion'].append(int(emotion))
                        data_valid['target'].append(target)
                        data_valid['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))

            with open('./data/' + opt.dataset + '/' + opt.dataset + '_ep_test.txt', 'r', encoding='utf-8') as f:
                lines = f.readlines()
                if opt.dataset == 'douban':
                    for line in tqdm(lines):
                        all = line.strip().split('\t')
                        emotion = all[-1]
                        context = ' '.join(all[:-1])
                        target = all[-2]
                        data_test['context'].append(context)
                        data_test['emotion'].append(int(emotion))
                        data_test['target'].append(target)
                        # data_test['context_indices'].append(preprocess_douban(context, tokenizer))
                        data_test['context_indices'].append(texts_to_ids_and_mask(all[:-1]))
                        data_test['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
                else:
                    for line in lines:
                        context, emotion, target = line.strip().split('\t')
                        data_test['context'].append(context)
                        data_test['emotion'].append(int(emotion))
                        data_test['target'].append(target)
                        data_test['src_bow'].append(bow_dictionary.doc2bow(context.strip().split(' ')))
            
            with open('./data/' + opt.dataset + '/dataset_' + opt.dataset + '_ep.p', "wb") as f:
                pickle.dump([data_train, data_valid, data_test], f)
                print("Saved PICKLE")
    if opt.only_train_ntm is not True:
        return data_train, data_valid, data_test  
    return data_train, data_test  
