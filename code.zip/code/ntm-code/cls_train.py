# -*- coding: utf-8 -*-

import imp
import os
import math
import argparse
import random
import numpy
import torch
import torch.nn as nn
from torch.nn.modules.loss import BCELoss
from torch.random import seed
from torch.utils import data
from torch.utils.data import (DataLoader, RandomSampler, SequentialSampler, TensorDataset)
from torch.utils.data import DataLoader, Dataset, RandomSampler
from transformers.models import bert
from transformers.utils.dummy_pt_objects import RobertaModel
from data_utils import build_embedding_matrix
from bucket_iterator import BucketIterator
from sklearn import metrics
from torch.autograd import Variable
from data_utils import ABSADatesetReader, prepare_data_seq
from models.bert import BERT, BERT_Large
from models.val_model import Val
from models.cls_model import Cls, Cls_s2s
from models.gpt2 import GPT2
from models.trans import Trans
from models.ntm import NTM, NTM_V2, NTM_V2_1, NTM_V2_2, train_ntm_one_epoch, test_ntm_one_epoch, train_ntm_model
from tqdm import tqdm
import logging
import pickle
from transformers import BertModel
from apex import amp
from ano_data_utils import prepare_data_seq_ano
from models.boe import BOE
from models.ep_model import BertForSequenceClassification, BertForSequenceClassification_V2, train_ep_model_weibo, train_ep_model_douban, Bert_NTMV2, Bert_NTMV2_1, Bert_NTMV2_2, Bert_Baidu
# from models.modeling_prior_v3 import BertForSequenceClassification_V2
from pytorch_pretrained_bert.optimization import BertAdam, warmup_linear
import time

class InputFeatures(object):
    def __init__(self, input_ids, input_mask, label_dist, label_id):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.label_dist = label_dist
        self.label_id = label_id

def get_input_features(file, dist_file):
    with open(file, 'rb') as f:
        features = pickle.load(f)
    with open(dist_file, 'rb') as f:
        dist_features = pickle.load(f)
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_input_mask = torch.tensor([f.input_mask for f in features], dtype=torch.long)
    all_data_bow = torch.tensor([f.label_dist for f in features], dtype=torch.float)
    all_label_id_dist = torch.tensor(dist_features, dtype=torch.float)
    # all_label_id_dist = torch.tensor([f.label_id for f in dist_features], dtype=torch.float)
    all_label_id = torch.tensor([int(f.label_id) for f in features], dtype=torch.long)
    data = TensorDataset(all_input_ids, all_input_mask, all_data_bow, all_label_id, all_label_id_dist)
    sampler = SequentialSampler(data)
    data_loader = DataLoader(data, sampler=sampler, batch_size=32)
    return data_loader

class Instructor:
    def __init__(self, opt):
        self.opt = opt
        if opt.only_train_ntm is not True:
            if opt.dataset == 'douban':
                logger.info("Loading Douban Input Features")
                self.train_data_loader = get_input_features('./data/douban/train_dataset_features')
                self.valid_data_loader = get_input_features('./data/douban/valid_dataset_features')
                self.test_data_loader = get_input_features('./data/douban/test_dataset_features')
                logger.info("Done!")
            else:
                logger.info("Loading Weibo Input Features")
                self.train_data_loader = get_input_features('./data/weibo/weibo_train_features', './data/weibo/weibo_ep_train_label_dist_features')
                self.valid_data_loader = get_input_features('./data/weibo/weibo_valid_features', './data/weibo/weibo_ep_dev_label_dist_features')
                self.test_data_loader = get_input_features('./data/weibo/weibo_test_features', './data/weibo/weibo_ep_test_label_dist_features')
                self.test_4_2_data_loader = get_input_features('./data/weibo/weibo_test_4_2_features', './data/weibo/weibo_ep_test_4_2_label_dist_features')
                self.test_4_3_data_loader = get_input_features('./data/weibo/weibo_test_4_3_features', './data/weibo/weibo_ep_test_4_3_label_dist_features')
                # self.train_data_loader = get_input_features('./weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_t4_multi_train.pkl', './weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_all_multi_train_dist.pkl')
                # self.valid_data_loader = get_input_features('./weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_t4_multi_dev.pkl', './weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_all_multi_dev_dist.pkl')
                # self.test_data_loader = get_input_features('./weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_t4_multi_test.pkl', './weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_all_multi_test_dist.pkl')
                # self.test_4_2_data_loader = get_input_features('./weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_t4_multi_test_4_2.pkl', './weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_all_multi_test_4_2_dist.pkl')
                # self.test_4_3_data_loader = get_input_features('./weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_t4_multi_test_4_3.pkl', './weibo-bert-base-baidu-cls-t4/dataset_topic_lda_news_multi_unsup_train_all_multi_test_4_3_dist.pkl')
                logger.info("Done!")
        else:
            if opt.dataset == 'douban':
                print('Loading Douban Dictionary ...')
                self.bow_dictionary = torch.load('./data/douban/bow_dict_v2.pt', 'wb')
            else:
                print('Loading Weibo Dictionary ...')
                self.bow_dictionary = torch.load('./data/weibo/bow_dict.pt', 'wb')
            self.train_data_loader, self.test_data_loader = prepare_data_seq(opt, self.bow_dictionary, opt.batch_size)
        
        # if 'ecg' in opt.dataset:
        #     logger.info("Loading BERT-Chinsese Embedding")
        #     self.bert = BertModel.from_pretrained('bert-base-chinese')
        #     self.embedding_matrix = torch.tensor(self.bert.embeddings.word_embeddings.weight)
        # else:
        #     logger.info("Loading BERT-English Embedding")
        #     self.bert = BertModel.from_pretrained('bert-base-uncased')
        #     self.embedding_matrix = torch.tensor(self.bert.embeddings.word_embeddings.weight)
        if opt.only_train_ntm:
            self.boe_model = BOE(opt).to(opt.device) 
            if opt.ntm_version == 'v2':   
                self.ntm_model = NTM_V2(opt).to(opt.device)
            elif opt.ntm_version == 'v2_1':
                self.ntm_model = NTM_V2_1(opt).to(opt.device)
            else:
                word2idx = self.bow_dictionary.token2id
                embedding_matrix = build_embedding_matrix(word2idx=word2idx, embed_dim=200)
                self.ntm_model = NTM_V2_2(opt, embedding_matrix).to(opt.device)

    
        # self.model = opt.model_class(opt).to(opt.device)
        # self._print_args()
        self.global_acc = 0.
        self.global_f1 = 0.
        self.global_loss = 10000.
        global_precision = 0.
        if opt.only_train_ntm:
            if opt.ntm_emo_cls:
                for name, param in self.boe_model.named_parameters():
                    if param.requires_grad: 
                        logger.info(name + '{0}'.format(param.size()))
            else:
                for name, param in self.ntm_model.named_parameters():
                    if param.requires_grad: 
                        logger.info(name + '{0}'.format(param.size()))
        # else:
        #     for name, param in self.model.named_parameters():
        #         if param.requires_grad: 
        #             logger.info(name + '{0}'.format(param.size()))

        if torch.cuda.is_available():
            logger.info('cuda memory allocated: {0}'.format(torch.cuda.memory_allocated(device=opt.device.index)))

    def _print_args(self):
        n_trainable_params, n_nontrainable_params = 0, 0
        if self.opt.only_train_ntm:
            for n, p in self.boe_model.named_parameters():
                if p.requires_grad:
                    logger.info('name: {0}, size: {1}'.format(n, p.shape))
            for p in self.ntm_model.parameters():
                n_params = torch.prod(torch.tensor(p.shape)).item()
                if p.requires_grad:
                    n_trainable_params += n_params
                else:
                    n_nontrainable_params += n_params
            logger.info('n_trainable_params: {0}, n_nontrainable_params: {1}'.format(n_trainable_params, n_nontrainable_params))
            logger.info('> training arguments:')
            for arg in vars(self.opt):
                logger.info('>>> {0}: {1}'.format(arg, getattr(self.opt, arg)))
        else:
            for p in self.model.parameters():
                n_params = torch.prod(torch.tensor(p.shape)).item()
                if p.requires_grad:
                    n_trainable_params += n_params
                else:
                    n_nontrainable_params += n_params
            logger.info('n_trainable_params: {0}, n_nontrainable_params: {1}'.format(n_trainable_params, n_nontrainable_params))
            logger.info('> training arguments:')
            for arg in vars(self.opt):
                logger.info('>>> {0}: {1}'.format(arg, getattr(self.opt, arg)))

    def _reset_params(self):
        print("para to reset")
        if self.opt.model_name == 'gpt2':
            for n, p in self.model.named_parameters():
                if p.requires_grad and 'encoder' not in n:
                    print(n)
                    if len(p.shape) > 1:
                        self.opt.initializer(p)
                    else:
                        stdv = 1. / math.sqrt(p.shape[0])
                        torch.nn.init.uniform_(p, a=-stdv, b=stdv)
        else:
            if opt.only_train_ntm:
                for n, p in self.boe_model.named_parameters():
                    if p.requires_grad and 'ntm' not in n:
                        print(n)
                        if len(p.shape) > 1:
                            self.opt.initializer(p)
                        else:
                            stdv = 1. / math.sqrt(p.shape[0])
                            torch.nn.init.uniform_(p, a=-stdv, b=stdv)
            else:
                for n, p in self.model.named_parameters():
                    if p.requires_grad and 'bert' not in n:
                        print(n)
                        if len(p.shape) > 1:
                            self.opt.initializer(p)
                        else:
                            stdv = 1. / math.sqrt(p.shape[0])
                            torch.nn.init.uniform_(p, a=-stdv, b=stdv)

    def subsequent_mask(self, size):
        """
        mask后续的位置，返回[size, size]尺寸下三角Tensor
        对角线及其左下角全是1，右上角全是0
        """
        attn_shape = (1, size, size)
        subsequent_mask = numpy.triu(numpy.ones(attn_shape), k=1).astype('uint8')
        return torch.from_numpy(subsequent_mask) == 0

    def make_std_mask(self, tgt, pad=0):
        "Create a mask to hide padding and future words."
        tgt_mask = (tgt != pad).unsqueeze(-2)
        tgt_mask = tgt_mask & Variable(
            self.subsequent_mask(tgt.size(-1)).type_as(tgt_mask.data))
        return tgt_mask

    def creat_mask(self, tgt):
        zero = torch.zeros_like(tgt).cuda()
        inf = torch.tensor(-1e9).expand_as(tgt).cuda()
        tgt = torch.where(tgt == 0, inf, tgt)
        tgt = torch.where(tgt > 0, zero, tgt)
        return tgt

    def _train(self, criterion, optimizer, repeat):
        max_test_acc = 0
        max_test_f1 = 0
        max_test_precision = 0
        max_test_recall = 0
        global_step = 0
        continue_not_increase = 0
        alpha = 0.
        for epoch in range(3): # self.opt.num_epoch
            logger.info('>' * 100)
            logger.info('epoch: {}'.format(epoch))
            n_correct, n_total = 0, 0
            increase_flag = False
            for i_batch, sample_batched in tqdm(enumerate(self.train_data_loader)):
                global_step += 1

                # switch model to training mode, clear gradient accumulators
                self.model.train()
                

                # inputs = [sample_batched[col].to(self.opt.device) if type(sample_batched[col])!=list else sample_batched[col] for col in self.opt.inputs_cols]
                # targets = sample_batched['polarity'].to(self.opt.device)
                input_batch = sample_batched['input_batch']
                response_batch = sample_batched['response_batch']
                # dialog_batch = sample_batched['dialog_batch']

                emo_targets = sample_batched['emotion']
                # print(emo_targets)
                emo_list = [item.item() for item in emo_targets]
                targets = torch.tensor(emo_list).to(self.opt.device)
                
                text_mask = (input_batch[:, 1:] != 0).float().to(self.opt.device)
                
                response_mask = (self.make_std_mask(response_batch[:, 1:], 0)).float()
                response_mask = self.creat_mask(response_mask).to(self.opt.device)
                inputs = [input_batch, response_batch, text_mask, response_mask]
                # inputs = [dialog_batch]
                # inputs = [input_batch]
                outputs = self.model(inputs)
                
                # try:
                #     outputs = self.model(inputs)
                # except RuntimeError as e:
                #     if 'out of memory' in str(e):
                #         print('| WARNING: ran out of memory')
                #         if hasattr(torch.cuda, 'empty_cache'):
                #             torch.cuda.empty_cache()
                #     else:
                #         raise e
                if global_step < 20000:
                    alpha += 1.0/20000
                if self.opt.add_kl:
                    loss, kl_loss = self.loss_function(outputs, targets, pri_mu, pri_logvar, rec_mu, rec_logvar, criterion, alpha)
                else:
                    loss = criterion(outputs, targets)

                if opt.gradient_accumulation_steps > 1:
                    loss = loss / opt.gradient_accumulation_steps

                # with amp.scale_loss(loss, optimizer) as scaled_loss:
                #     scaled_loss.backward()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.opt.max_grad_norm)
                
                if (i_batch + 1) % opt.gradient_accumulation_steps == 0:
                    optimizer.step()
                    optimizer.zero_grad()
                
                if global_step % self.opt.log_step == 0:
                    n_correct += (torch.argmax(outputs, -1) == targets).sum().item()
                    n_total += len(outputs)
                    train_acc = n_correct / n_total
                    train_precision = metrics.precision_score(targets.cpu(), torch.argmax(outputs, -1).cpu(), average='macro')
                    self.opt.is_train = False
                    test_acc, test_f1, test_loss, test_precision, test_recall, report = self._evaluate_acc_f1(criterion, alpha)
                    self.opt.is_train = True
                    if test_acc > max_test_acc:
                        max_test_acc = test_acc
                    if test_f1 > max_test_f1:
                        increase_flag = True
                        max_test_acc = test_acc
                        max_test_precision = test_precision
                        max_test_recall = test_recall
                        max_test_f1 = test_f1
                        if self.opt.save and test_f1 > self.global_f1:
                            self.global_f1 = test_f1
                            torch.save(self.model.state_dict(), 'state_dict/cls_'+self.opt.model_name+'_'+self.opt.dataset+'_' + str(self.opt.learning_rate) + '_' + str(repeat) + '.pkl')
                            logger.info('>>> best model saved.')
                            logger.info('{0}'.format(report))
                    if self.opt.add_kl:
                        logger.info('loss: {:.4f}, kl_loss: {:.4f}, acc: {:.4f}, test_acc: {:.4f}, test_precision: {:.4f}, test_recall: {:.4f}, test_f1: {:.4f}, test_loss: {:.4f}'.format(loss.item(), kl_loss.item(), train_acc, test_acc, test_precision, test_recall, test_f1, test_loss))
                    else:
                        logger.info('loss: {:.4f}, acc: {:.4f}, test_acc: {:.4f}, test_precision: {:.4f}, test_recall: {:.4f}, test_f1: {:.4f}, test_loss: {:.4f}'.format(loss.item(), train_acc, test_acc, test_precision, test_recall, test_f1, test_loss))
                    # print(report)
            if increase_flag == False:
                continue_not_increase += 1
                if continue_not_increase >= 5:
                    logger.info('early stop.')
                    break
            else:
                continue_not_increase = 0    
        return max_test_acc, max_test_f1, max_test_precision, max_test_recall

    def _evaluate_acc_f1(self, criterion, alpha):
        # switch model to evaluation mode
        self.model.eval()
        n_test_correct, n_test_total = 0, 0
        t_targets_all, t_outputs_all = None, None
        with torch.no_grad():
            for t_batch, t_sample_batched in enumerate(self.test_data_loader):
                # t_inputs = [t_sample_batched[col].to(opt.device) if type(t_sample_batched[col])!=list else t_sample_batched[col] for col in self.opt.inputs_cols]
                # t_targets = t_sample_batched['polarity'].to(opt.device)
                input_batch = t_sample_batched['input_batch']
                response_batch = t_sample_batched['response_batch']
                # dialog_batch = t_sample_batched['dialog_batch']
                emo_targets = t_sample_batched['emotion']
                emo_list = [item.item() for item in emo_targets]
                targets = torch.tensor(emo_list).to(self.opt.device)
                
                text_mask = (input_batch[:, 1:] != 0).float().to(self.opt.device)
                response_mask = (self.make_std_mask(response_batch[:, 1:], 0)).float()
                response_mask = self.creat_mask(response_mask).to(self.opt.device)
                inputs = [input_batch, response_batch, text_mask, response_mask]
                # inputs = [input_batch]
                # inputs = [dialog_batch]
                
                t_outputs = self.model(inputs)
                
                loss = criterion(t_outputs, targets)
                n_test_correct += (torch.argmax(t_outputs, -1) == targets).sum().item()
                n_test_total += len(t_outputs)
                if t_targets_all is None:
                    t_targets_all = targets
                    t_outputs_all = t_outputs
                else:
                    t_targets_all = torch.cat((t_targets_all, targets), dim=0)
                    t_outputs_all = torch.cat((t_outputs_all, t_outputs), dim=0)
        test_acc = n_test_correct / n_test_total
        if self.opt.dataset == 'dialogues':
            precision = metrics.precision_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), average='macro')
            recall = metrics.recall_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), average='macro')
            f1 = metrics.f1_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2, 3, 4, 5, 6], average='macro')
            report = metrics.classification_report(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu())
        elif self.opt.dataset == 'douban':
            precision = metrics.precision_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2, 3, 4], average='macro')
            recall = metrics.recall_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2 ,3 ,4], average='macro')
            f1 = metrics.f1_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2, 3, 4], average='macro')
            report = metrics.classification_report(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2, 3, 4])
        else:
            precision = metrics.precision_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), average='macro')
            recall = metrics.recall_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), average='macro')
            f1 = metrics.f1_score(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu(), labels=[0, 1, 2, 3, 4, 5], average='macro')
            report = metrics.classification_report(t_targets_all.cpu(), torch.argmax(t_outputs_all, -1).cpu())
        return test_acc, f1, loss.item(), precision, recall, report

    def _anotate_data(self, repeat):
        self.model.eval()
        logits = []
        emos = []
        f_out = open('./ano_results/bert_logits_5.pkl', 'wb')
        f_ori_out = open('./ori_data_sorted.txt', 'w', encoding='utf-8')
        t_targets_all, t_outputs_all = None, None
        n_test_correct, n_test_total = 0, 0
        context_list = []
        with torch.no_grad():
            for t_sample_batched in tqdm(self.ano_data_loader):
                # input_batch = t_sample_batched['input_batch'].cuda()
                context = t_sample_batched['context'] 
                for item in context:
                    context_list.append(item.strip())             
                # inputs = [input_batch]
                # t_outputs = nn.functional.softmax(self.model(inputs), dim=1)#.cpu().numpy()
                # for item in t_outputs:
                #     logits.append(item)
            # pickle.dump(logits, f_out)
        for item in context_list:
            f_ori_out.write(item + '\n')

    def set_seed(self, seed):
        random.seed(seed)
        numpy.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    def run(self, repeats=5):
        if self.opt.ano:
            criterion = nn.CrossEntropyLoss()
            self.model.load_state_dict(torch.load('./state_dict/cls_bert_large_douban_1e-05_5.pkl'))
            self._anotate_data(0)
        elif self.opt.only_train_ntm:
            criterion = nn.CrossEntropyLoss()
            if opt.ntm_emo_cls:
                _params = filter(lambda p: p.requires_grad, self.boe_model.parameters())
            else:
                _params = filter(lambda p: p.requires_grad, self.ntm_model.parameters())
            optimizer = self.opt.optimizer(_params, lr=self.opt.learning_rate)
            if self.opt.fp16:
                try:
                    from apex import amp
                except ImportError:
                    raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
                self.ntm_model, optimizer = amp.initialize(self.ntm_model, optimizer, opt_level=opt.fp16_opt_level)
            # self._reset_params()
            train_ntm_model(self.opt, logger, self.ntm_model, self.boe_model, self.train_data_loader, self.test_data_loader, self.bow_dictionary, optimizer, criterion)
        elif self.opt.emo_plan:
            test_loss = []
            test_emo_loss = []
            valid_loss = []
            valid_emo_loss = []
            test_4_2_whole_loss = []
            test_4_2_emo_loss = []
            test_4_3_whole_loss = []
            test_4_3_emo_loss = []
            dev_dist_whole_kl = []
            dev_dist_emo_kl = []
            test_dist_whole_kl = []
            test_dist_emo_kl = []
            test_4_2_dist_whole_kl = []
            test_4_2_dist_emo_kl = []
            test_4_3_dist_whole_kl = []
            test_4_3_dist_emo_kl = []
            for i in range(self.opt.start, self.opt.end):
                seed = i+1
                self.set_seed(seed)
                logger.info('repeat: {0}'.format(i+1))

                if self.opt.model_name == 'bert':
                    self.model = opt.model_class(opt).to(opt.device)
                elif self.opt.model_name == 'bert_baidu':
                    logger.info("Using Baidu Model!")
                    self.model = Bert_Baidu.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                elif self.opt.model_name == 'bert_ntmv2':
                    self.model = Bert_NTMV2.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                    if self.opt.topic_num == 50:
                        self.model.topic_prior.load_state_dict(torch.load('Emo-plan/state_dict/e50.val_loss=2.169.sparsity=0.992.ntm_model_v2_1_weibo_topic50'))
                elif self.opt.model_name == 'bert_ntmv2_1':
                    self.model = Bert_NTMV2_1.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                    if self.opt.dataset == 'douban':
                        self.model.topic_prior.load_state_dict(torch.load('./state_dict/e100.val_loss=1.507.sparsity=0.856.ntm_model_v2_1'))
                    else:
                        if self.opt.topic_num == 40:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/e10.val_loss=2.104.sparsity=0.014.ntm_model_v2_1_weibo_topic40'))
                        if self.opt.topic_num == 50:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/e30.val_loss=2.142.sparsity=0.573.ntm_model_v2_1_weibo_topic50'))
                        if self.opt.topic_num == 80:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/e20.val_loss=2.110.sparsity=0.059.ntm_model_v2_1_weibo_topic80'))
                        if self.opt.topic_num == 100:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/e20.val_loss=2.120.sparsity=0.057.ntm_model_v2_1_weibo_topic100'))
                        if self.opt.topic_num == 120:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/e20.val_loss=2.119.sparsity=0.046.ntm_model_v2_1_weibo_topic120'))
                elif self.opt.model_name == 'bert_ntmv2_2':
                    self.model = Bert_NTMV2_2.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                    self.model.topic_prior.load_state_dict(torch.load('./state_dict/e100.val_loss=1.499.sparsity=0.865.ntm_model_v2_2')) # 预训练腾讯词向量
                else:
                    if self.opt.fusion_version == 'v1':
                        logger.info("------------Using Model BertForSequenceClassification--------------")
                        self.model = BertForSequenceClassification.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                    else:
                        self.model = BertForSequenceClassification_V2.from_pretrained(opt.bert_dir, num_labels=opt.polarities_dim, opt=opt).to(opt.device)
                    if self.opt.topic_num == 40: 
                        if self.opt.topic_type == 'z':
                            logger.info("-------------Using Model boe_topic40_soft_label---------------")
                            # self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic40_soft_label'))
                        else:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic40_mlp_g'))
                        # self.model.topic_prior.load_state_dict(torch.load('./state_dict/e100.val_loss=198.012.sparsity=0.846.ntm_model_topic40'))
                    elif self.opt.topic_num == 50:
                        if self.opt.topic_type == 'z':
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic50_mlp_z'))
                        else:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic50_mlp_g'))
                    elif self.opt.topic_num == 30:
                        if self.opt.topic_type == 'z':
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic30_mlp_z'))
                        else:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic30_mlp_g'))
                    else:
                        if self.opt.topic_type == 'z':
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic60_mlp_z'))
                        else:
                            self.model.topic_prior.load_state_dict(torch.load('./state_dict/boe_topic60_mlp_g'))

                # if opt.only_train_ntm:
                #     if opt.ntm_emo_cls:
                #         for name, param in self.boe_model.named_parameters():
                #             if param.requires_grad: 
                #                 logger.info(name + '{0}'.format(param.size()))
                #     else:
                #         for name, param in self.ntm_model.named_parameters():
                #             if param.requires_grad: 
                #                 logger.info(name + '{0}'.format(param.size()))
                # else:
                #     for name, param in self.model.named_parameters():
                #         if param.requires_grad: 
                #             logger.info(name + '{0}'.format(param.size()))

                # _params = filter(lambda p: p.requires_grad, self.model.parameters())
                # optimizer = self.opt.optimizer(_params, lr=self.opt.learning_rate, weight_decay=self.opt.l2reg)
                
                num_train_optimization_steps = len(self.train_data_loader) * self.opt.ep_epoch / self.opt.gradient_accumulation_steps
                param_optimizer = list(self.model.named_parameters())
                no_decay = ['bias', 'LayerNorm.bias', 'LayerNorm.weight']
                optimizer_grouped_parameters = [
                    {'params': [p for n, p in param_optimizer if not any(nd in n for nd in no_decay)],
                     'weight_decay': 0.0},
                    {'params': [p for n, p in param_optimizer if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
                ]
                optimizer = BertAdam(optimizer_grouped_parameters,
                        lr=self.opt.learning_rate,
                        warmup=0.06,
                        schedule='warmup_linear',
                        t_total=num_train_optimization_steps)
                
                if self.opt.fp16:
                    try:
                        from apex import amp
                    except ImportError:
                        raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
                    self.model, optimizer = amp.initialize(self.model, optimizer, opt_level=opt.fp16_opt_level)
                
                if self.opt.use_baidu_topic:
                    with open('./baidu_topic_dist/dataset_topic_lda_news_multi_unsup_train_t2_multi_train.pkl', 'rb') as f:
                        train_features = pickle.load(f)
                    with open('./baidu_topic_dist/dataset_topic_lda_news_multi_unsup_train_t2_multi_dev.pkl', 'rb') as f:
                        eval_features = pickle.load(f)
                    with open('./baidu_topic_dist/dataset_topic_lda_news_multi_unsup_train_t2_multi_test.pkl', 'rb') as f:
                        test_features = pickle.load(f)
                    all_input_ids = torch.tensor([f.input_ids for f in eval_features], dtype=torch.long)
                    all_input_mask = torch.tensor([f.input_mask for f in eval_features], dtype=torch.long)
                    all_label_dist = torch.tensor([f.label_dist for f in eval_features], dtype=torch.float)
                    all_label_id = torch.tensor([int(f.label_id) for f in eval_features], dtype=torch.long)
                    eval_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
                    eval_sampler = SequentialSampler(eval_data)
                    eval_dataloader = DataLoader(eval_data, sampler=eval_sampler, batch_size=32)
                    all_input_ids = torch.tensor([f.input_ids for f in train_features], dtype=torch.long)
                    all_input_mask = torch.tensor([f.input_mask for f in train_features], dtype=torch.long)
                    all_label_dist = torch.tensor([f.label_dist for f in train_features], dtype=torch.float)
                    all_label_id = torch.tensor([int(f.label_id) for f in train_features], dtype=torch.long)
                    train_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
                    train_sampler = RandomSampler(train_data)
                    train_dataloader = DataLoader(train_data, sampler=train_sampler, batch_size=32)
                    all_input_ids = torch.tensor([f.input_ids for f in test_features], dtype=torch.long)
                    all_input_mask = torch.tensor([f.input_mask for f in test_features], dtype=torch.long)
                    all_label_dist = torch.tensor([f.label_dist for f in test_features], dtype=torch.float)
                    all_label_id = torch.tensor([int(f.label_id) for f in test_features], dtype=torch.long)
                    test_data = TensorDataset(all_input_ids, all_input_mask, all_label_dist, all_label_id)
                    test_sampler = RandomSampler(test_data)
                    test_dataloader = DataLoader(test_data, sampler=test_sampler, batch_size=32)
                    min_test_loss, min_emo_loss, min_valid_loss, min_valid_emo_loss = train_ep_model(opt, logger, self.model, train_dataloader, eval_dataloader, test_dataloader, optimizer)
                else:
                    if self.opt.dataset == 'douban':
                        min_test_loss, min_emo_loss, min_valid_loss, min_valid_emo_loss = train_ep_model_douban(opt, logger, self.model, self.train_data_loader, self.valid_data_loader, self.test_data_loader, optimizer)
                    else:
                        min_test_whole_loss, min_test_emo_loss, min_valid_whole_loss, min_valid_emo_loss, min_test_4_2_whole_loss, min_test_4_2_emo_loss, \
                        min_test_4_3_whole_loss, min_test_4_3_emo_loss, min_dev_dist_whole_loss, min_dev_dist_emo_loss, min_test_dist_whole_loss, min_test_dist_emo_loss, \
                        min_test_4_2_dist_whole_loss, min_test_4_2_dist_emo_loss, min_test_4_3_dist_whole_loss, min_test_4_3_dist_emo_loss = train_ep_model_weibo(opt, logger, self.model, self.train_data_loader, self.valid_data_loader, self.test_data_loader, self.test_4_2_data_loader, self.test_4_3_data_loader, optimizer)
                    # min_test_loss, min_emo_loss = train_ep_model(opt, logger, self.model, self.train_data_loader, self.test_data_loader, optimizer)
                
                test_loss.append(min_test_whole_loss)
                test_emo_loss.append(min_test_emo_loss)
                valid_loss.append(min_valid_whole_loss)
                valid_emo_loss.append(min_valid_emo_loss)
                test_4_2_whole_loss.append(min_test_4_2_whole_loss)
                test_4_2_emo_loss.append(min_test_4_2_emo_loss)
                test_4_3_whole_loss.append(min_test_4_3_whole_loss)
                test_4_3_emo_loss.append(min_test_4_3_emo_loss)
                dev_dist_whole_kl.append(min_dev_dist_whole_loss)
                dev_dist_emo_kl.append(min_dev_dist_emo_loss)
                test_dist_whole_kl.append(min_test_dist_whole_loss)
                test_dist_emo_kl.append(min_test_dist_emo_loss)
                test_4_2_dist_whole_kl.append(min_test_4_2_dist_whole_loss)
                test_4_2_dist_emo_kl.append(min_test_4_2_dist_emo_loss)
                test_4_3_dist_whole_kl.append(min_test_4_3_dist_whole_loss)
                test_4_3_dist_emo_kl.append(min_test_4_3_dist_emo_loss)
            
            def compute_avg_scores(result):
                sum = 0
                for item in result:
                    sum += item
                avg = sum / len(result)
                return avg

            avg_test_loss = compute_avg_scores(test_loss)
            avg_test_emo_loss = compute_avg_scores(test_emo_loss)
            avg_valid_loss = compute_avg_scores(valid_loss)
            avg_valid_emo_loss = compute_avg_scores(valid_emo_loss)
            avg_test_4_2_whole_loss = compute_avg_scores(test_4_2_whole_loss)
            avg_test_4_2_emo_loss = compute_avg_scores(test_4_2_emo_loss)
            avg_test_4_3_whole_loss = compute_avg_scores(test_4_3_whole_loss)
            avg_test_4_3_emo_loss = compute_avg_scores(test_4_3_emo_loss)
            avg_dev_dist_whole_kl = compute_avg_scores(dev_dist_whole_kl)
            avg_dev_dist_emo_kl = compute_avg_scores(dev_dist_emo_kl)
            avg_test_dist_whole_kl = compute_avg_scores(test_dist_whole_kl)
            avg_test_dist_emo_kl = compute_avg_scores(test_dist_emo_kl)
            avg_test_4_2_dist_whole_kl = compute_avg_scores(test_4_2_dist_whole_kl)
            avg_test_4_2_dist_emo_kl = compute_avg_scores(test_4_2_dist_emo_kl)
            avg_test_4_3_dist_whole_kl = compute_avg_scores(test_4_3_dist_whole_kl)
            avg_test_4_3_dist_emo_kl = compute_avg_scores(test_4_3_dist_emo_kl)
            logger.info('all_test_whole_loss: {0}, avg_test_whole_loss: {1}'.format(str(test_loss), str(avg_test_loss)))
            logger.info('all_test_emo_loss: {0}, avg_test_emo_loss: {1}'.format(str(test_emo_loss), str(avg_test_emo_loss)))
            logger.info('all_valid_whole_loss: {0}, avg_valid_whole_loss: {1}'.format(str(valid_loss), str(avg_valid_loss)))
            logger.info('all_valid_emo_loss: {0}, avg_valid_emo_loss: {1}'.format(str(valid_emo_loss), str(avg_valid_emo_loss)))
            logger.info('all_test_4_2_whole_loss: {0}, avg_test_4_2_whole_loss: {1}'.format(str(test_4_2_whole_loss), str(avg_test_4_2_whole_loss)))
            logger.info('all_test_4_2_emo_loss: {0}, avg_test_4_2_emo_loss: {1}'.format(str(test_4_2_emo_loss), str(avg_test_4_2_emo_loss)))
            logger.info('all_test_4_3_whole_loss: {0}, avg_test_4_3_whole_loss: {1}'.format(str(test_4_3_whole_loss), str(avg_test_4_3_whole_loss)))
            logger.info('all_test_4_3_emo_loss: {0}, avg_test_4_3_emo_loss: {1}'.format(str(test_4_3_emo_loss), str(avg_test_4_3_emo_loss)))
            logger.info('all_dev_dist_whole_kl: {0}, avg_dev_dist_whole_kl: {1}'.format(str(dev_dist_whole_kl), str(avg_dev_dist_whole_kl)))
            logger.info('all_dev_dist_emo_kl: {0}, avg_dev_dist_emo_kl: {1}'.format(str(dev_dist_emo_kl), str(avg_dev_dist_emo_kl)))
            logger.info('all_test_dist_whole_kl: {0}, avg_test_dist_whole_kl: {1}'.format(str(test_dist_whole_kl), str(avg_test_dist_whole_kl)))
            logger.info('all_test_dist_emo_kl: {0}, avg_test_dist_emo_kl: {1}'.format(str(test_dist_emo_kl), str(avg_test_dist_emo_kl)))
            logger.info('all_test_4_2_dist_whole_kl: {0}, avg_test_4_2_dist_whole_kl: {1}'.format(str(test_4_2_dist_whole_kl), str(avg_test_4_2_dist_whole_kl)))
            logger.info('all_test_4_2_dist_emo_kl: {0}, avg_test_4_2_dist_emo_kl: {1}'.format(str(test_4_2_dist_emo_kl), str(avg_test_4_2_dist_emo_kl)))
            logger.info('all_test_4_3_dist_whole_kl: {0}, avg_test_4_3_dist_whole_kl: {1}'.format(str(test_4_3_dist_whole_kl), str(avg_test_4_3_dist_whole_kl)))
            logger.info('all_test_4_3_dist_emo_kl: {0}, avg_test_4_3_dist_emo_kl: {1}'.format(str(test_4_3_dist_emo_kl), str(avg_test_4_3_dist_emo_kl)))
        else:
            # Loss and Optimizer
            criterion = nn.CrossEntropyLoss()

            if not os.path.exists('log/'):
                os.mkdir('log/')

            f_out = open('log/cls_'+self.opt.model_name+'_'+self.opt.dataset+'_'+str(opt.learning_rate), 'w', encoding='utf-8')

            max_test_acc_avg = 0
            max_test_f1_avg = 0
            max_result = []
            for i in range(repeats):
                self.global_f1 = 0.
                logger.info('repeat: {0}'.format(i+1))
                f_out.write('repeat: '+str(i+1) + '\n')
                seed = i+1
            
                self.model = opt.model_class(opt, self.embedding_matrix).to(opt.device)
                self.set_seed(seed)
                self._reset_params()
                _params = filter(lambda p: p.requires_grad, self.model.parameters())
                optimizer = self.opt.optimizer(_params, lr=self.opt.learning_rate, weight_decay=self.opt.l2reg)
                # self.model, optimizer = amp.initialize(self.model, optimizer, opt_level="O1")
                max_test_acc, max_test_f1, max_test_precision, max_test_recall = self._train(criterion, optimizer, i+1)
                logger.info('max_test_acc: {0}, max_test_f1: {1}, max_test_precision: {2}, max_test_recall: {3}'.format(max_test_acc, max_test_f1, max_test_precision, max_test_recall))
                f_out.write('max_test_acc: {0}, max_test_f1: {1}, max_test_precision: {2}, max_test_recall: {3}'.format(max_test_acc, max_test_f1, max_test_precision, max_test_recall))
                max_result.append((max_test_acc, max_test_f1))

                max_test_acc_avg += max_test_acc
                max_test_f1_avg += max_test_f1
                print('#' * 100)
            max_acc, max_f1 = max(max_result, key=lambda x:x[0])
            f_out.write(str(max_acc) + '\t' + str(max_f1) + '\n')
            f_out.write("test_acc_avg:" + str(max_test_acc_avg / repeats) + '\n')
            f_out.write("test_f1_avg:" + str(max_test_f1_avg / repeats) + '\n')
            print("max_test_acc_avg:", max_test_acc_avg / repeats)
            print("max_test_f1_avg:", max_test_f1_avg / repeats)

            f_out.close()

def get_logger(filename, verbosity=1, name=None):
    level_dict = {0: logging.DEBUG, 1: logging.INFO, 2: logging.WARNING}
    formatter = logging.Formatter(
        "[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s"
    )
    logger = logging.getLogger(name)
    logger.setLevel(level_dict[verbosity])

    fh = logging.FileHandler(filename, "w")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    return logger

if __name__ == '__main__':
    # Hyper Parameters
    # torch.multiprocessing.set_start_method('spawn')
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_name', default='bert', type=str)
    parser.add_argument('--dataset', default='dialogues', type=str, help='dialogues_ep, iemocap, iemocap_ep')
    parser.add_argument('--optimizer', default='adam', type=str)
    parser.add_argument('--initializer', default='xavier_uniform_', type=str)
    parser.add_argument('--learning_rate', default=0.0001, type=float)
    parser.add_argument('--l2reg', default=0.00001, type=float)
    parser.add_argument('--num_epoch', default=100, type=int)
    parser.add_argument('--ep_epoch', default=3, type=int)
    parser.add_argument('--ntm_warm_up_epochs', default=100, type=int)
    parser.add_argument('--batch_size', default=8, type=int)
    parser.add_argument('--gradient_accumulation_steps', default=4, type=int)
    parser.add_argument('--hidden_dim', default=768, type=int)
    parser.add_argument('--pri_dim', default=256, type=int)
    parser.add_argument('--rec_dim', default=256, type=int)
    parser.add_argument('--en_layer_num', default=6, type=int)
    parser.add_argument('--de_layer_num', default=6, type=int)
    parser.add_argument('--cls_layer_num', default=3, type=int)
    parser.add_argument('--ffn_dim', default=3072, type=int)
    parser.add_argument('--ffn_dropout', default=0.1, type=float)
    parser.add_argument('--dropout', default=0.2, type=float)
    parser.add_argument('--num_attention_heads', default=8, type=int)
    parser.add_argument('--attention_probs_dropout_prob', default=0.1, type=float)

    parser.add_argument('--save_path', default='./state_dict/', type=str)
    parser.add_argument('--topic_num', type=int, default=50)
    parser.add_argument('--topic_vector_dim', type=int, default=512)
    parser.add_argument('--bow_vocab_size', default=5000, type=int)
    parser.add_argument('--target_sparsity', type=float, default=0.85, help="Target sparsity for ntm model")
    parser.add_argument('--log_step', default=5, type=int)
    parser.add_argument('--polarities_dim', default=5, type=int)
    parser.add_argument('--bert_dir', default='./chinese_roberta_wwm_ext_pytorch', type=str)
    parser.add_argument('--save', default=False, type=bool)
    parser.add_argument('--layernorm', default=False, type=bool)
    parser.add_argument('--emo_plan', default=False, type=bool)
    parser.add_argument('--only_train_ntm', default=False, type=bool)
    parser.add_argument('--dev_or_test', default='test', type=str)
    parser.add_argument('--ntm_version', default='v2', type=str)
    parser.add_argument('--ntm_with_emo', default=False, type=bool)
    parser.add_argument('--ntm_emo_cls', default=False, type=bool)
    parser.add_argument('--use_emo_mlp', default=False, type=bool)
    parser.add_argument('--use_emo_vector', default=False, type=bool)
    parser.add_argument('--use_baidu_topic', default=False, type=bool)
    parser.add_argument('--topic_type', default='z', type=str)
    parser.add_argument('--fusion_version', default='v1', type=str)
    parser.add_argument('--use_topic_represent', default=False, type=bool)
    parser.add_argument('--is_train', default=True, type=bool)
    parser.add_argument('--add_one_hot', default=False, type=bool)
    parser.add_argument('--add_kl', default=False, type=bool)
    parser.add_argument('--ano', default=False, type=bool)
    parser.add_argument('--dist_as_loss', default=False, type=bool)
    parser.add_argument('--seed', default=776, type=int)
    parser.add_argument('--start', default=776, type=int)
    parser.add_argument('--end', default=776, type=int)
    parser.add_argument('--device', default=None, type=str)
    parser.add_argument('--gen_path', default=None, type=str)
    parser.add_argument("--max_grad_norm", default=1.0, type=float, help="Max gradient norm.")
    parser.add_argument('--fp16', default=False, type=bool, help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    parser.add_argument('--fp16_opt_level', type=str, default='O1', help="For fp16: Apex AMP optimization level selected in ['O0', 'O1', 'O2', and 'O3'].")
    opt = parser.parse_args()

    logger = get_logger('log/' + opt.model_name + '_' + opt.dataset + '_ep_debug.log')

    if opt.dataset == 'dialogues':
        opt.polarities_dim = 7
    elif opt.dataset == 'ecg':
        opt.polarities_dim = 6
    else:
        opt.polarities_dim = 5

    # if opt.dataset == 'ecg' or opt.dataset == 'ecg_ep':
    #     opt.batch_size = 32

    model_classes = {
        'bert': BERT,
        'bert_large': BERT_Large,
        'val': Val,
        'cls': Cls,
        'cls_s2s': Cls_s2s,
        'gpt2': GPT2,
        'trans': Trans,
        'ntm': NTM,
        'boe': BOE
    }
    input_colses = {
        'bert': ['text_indices'],
        'bert_large': ['text_indices'],
        'gpt2': ['text_indices'],
        'trans': ['text_indices'],
        'val': ['text_indices', 'response_indices', 'text_mask', 'response_mask'],
        'cls': ['text_indices', 'response_indices', 'text_mask', 'response_mask'],
        'cls_s2s': ['text_indices', 'response_indices', 'text_mask', 'response_mask'],
    }
    initializers = {
        'xavier_uniform_': torch.nn.init.xavier_uniform_,
        'xavier_normal_': torch.nn.init.xavier_normal_,
        'orthogonal_': torch.nn.init.orthogonal_,
    }
    optimizers = {
        'adam': torch.optim.Adam,  # default lr=0.001
        'rmsprop': torch.optim.RMSprop,  # default lr=0.01
        'sgd': torch.optim.SGD,
    }
    if opt.model_name == 'bert':
        opt.model_class = model_classes[opt.model_name]
    # opt.inputs_cols = input_colses[opt.model_name]
    opt.initializer = initializers[opt.initializer]
    opt.optimizer = optimizers[opt.optimizer]
    print(torch.cuda.is_available())
    opt.device = torch.device('cuda')
    # opt.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') \
    #     if opt.device is None else torch.device(opt.device)
    print(opt.device)
    ins = Instructor(opt)
    ins.run()
